/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Warm off-white page background + soft sections
        cream: { DEFAULT: '#FAF5EC', dark: '#F3E9D6' },
        // Sand / beige — cards and soft panels
        sand: { light: '#F6EEDE', DEFAULT: '#EFE3CD', dark: '#E3D3B4' },
        // Espresso — dark sections, footer, deep text
        espresso: {
          DEFAULT: '#2B1C10',
          950: '#150C05',
          900: '#1E130A',
          800: '#2B1C10',
          700: '#3C2917',
          600: '#523B23',
        },
        // Walnut — brown headings / secondary text on light
        walnut: { DEFAULT: '#5B3E24', light: '#7C5734' },
        // Gold / caramel — accent, CTAs, highlights
        gold: {
          DEFAULT: '#B4813A',
          bright: '#CAA15C',
          deep: '#9A6828',
          dark: '#835820',
          50: '#F6E9CF',
        },
        // Muted warm grey-brown — small labels (darkened to clear 4.5:1 AA on cream)
        taupe: { DEFAULT: '#6E5E4A', light: '#8C7B65' },
        // Primary body text
        ink: '#2E2016',
        line: { DEFAULT: '#E7D9C1', dark: 'rgba(250,245,236,0.12)' },
      },
      fontFamily: {
        display: ['Fraunces', 'ui-serif', 'Georgia', 'serif'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      maxWidth: { container: '1200px' },
      borderRadius: { '2xl': '1.25rem', '3xl': '1.75rem', '4xl': '2.25rem' },
      boxShadow: {
        card: '0 18px 44px -22px rgba(43,28,16,0.30)',
        soft: '0 10px 30px -16px rgba(43,28,16,0.28)',
        gold: '0 14px 30px -12px rgba(154,104,40,0.45)',
        'inner-line': 'inset 0 0 0 1px rgba(43,28,16,0.06)',
      },
      letterSpacing: { tightish: '-0.01em' },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        float: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        shimmer: {
          '100%': { transform: 'translateX(100%)' },
        },
        marquee: {
          to: { transform: 'translateX(-50%)' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.6s ease-out both',
        float: 'float 6s ease-in-out infinite',
        marquee: 'marquee 34s linear infinite',
      },
    },
  },
  plugins: [],
}
