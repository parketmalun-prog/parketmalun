export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(' ')
}

/**
 * Build an Unsplash image URL from a photo id.
 * NOTE: These are high-quality placeholder photos. Replace the ids in the
 * data files (src/data/*) with the client's own project photos when ready.
 * `auto=format` already negotiates AVIF/WebP; q defaults to 70 (visually
 * lossless for photos at these sizes, ~15-25% lighter than q=80).
 */
export function img(id: string, w = 1200, q = 70): string {
  return `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=${q}`
}

/**
 * Build a responsive `{ src, srcSet }` pair for an <img>. Pass the candidate
 * pixel widths the layout can actually use (roughly display-width × 1–2 DPR);
 * the browser then picks the smallest that fits, so phones download small
 * variants instead of the desktop image. Combine with a `sizes` attribute.
 */
export function imgSet(id: string, widths: number[], q = 70): { src: string; srcSet: string } {
  const sorted = [...widths].sort((a, b) => a - b)
  const srcSet = sorted.map((w) => `${img(id, w, q)} ${w}w`).join(', ')
  // Fallback for the rare no-srcset UA: a mid-size variant, never the largest.
  const fallback = sorted.find((w) => w >= 768) ?? sorted[sorted.length - 1]
  return { src: img(id, fallback, q), srcSet }
}

/** Icelandic króna formatting, e.g. 13900 -> "13.900 kr." (period as thousands separator). */
export function formatIsk(n: number): string {
  const grouped = Math.round(n)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, '.')
  return `${grouped} kr.`
}

export function scrollToTop(): void {
  if (typeof window !== 'undefined') window.scrollTo({ top: 0, left: 0, behavior: 'auto' })
}
