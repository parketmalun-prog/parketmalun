import { Home as HomeIcon } from 'lucide-react'
import { IconPhoneRing } from '@/components/icons'
import { site } from '@/data/site'
import { useLang, useUi } from '@/i18n/context'
import { Seo } from '@/components/Seo'
import { Button } from '@/components/Button'
import { LogoMark } from '@/components/Logo'

export default function NotFound() {
  const { path } = useLang()
  const t = useUi()
  return (
    <>
      <Seo title={t.notFound.seoTitle} noindex />
      <section className="flex min-h-[70vh] items-center justify-center bg-gradient-to-b from-sand-light to-cream">
        <div className="container-x flex flex-col items-center py-20 text-center">
          <LogoMark className="h-16 w-auto opacity-80" />
          <p className="mt-8 font-display text-6xl font-semibold text-gold-deep">404</p>
          <h1 className="mt-4 font-display text-3xl font-semibold text-espresso">{t.notFound.title}</h1>
          <p className="mt-3 max-w-md text-ink/70">{t.notFound.text}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button to={path('home')} variant="primary" icon={<HomeIcon className="h-4 w-4" />}>
              {t.notFound.backHome}
            </Button>
            <Button href={`tel:${site.phoneRaw}`} variant="outline" icon={<IconPhoneRing className="h-4 w-4" />}>
              {site.phone}
            </Button>
          </div>
        </div>
      </section>
    </>
  )
}
