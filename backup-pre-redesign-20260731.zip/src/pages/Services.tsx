import { ArrowRight } from 'lucide-react'
import { cn, imgSet } from '@/lib/utils'
import { site, serviceImages } from '@/data/site'
import { services as servicesByLang, servicesIntro as servicesIntroByLang, servicesSeo as servicesSeoByLang } from '@/data/services'
import { useContent, useLang, useUi } from '@/i18n/context'
import { Seo } from '@/components/Seo'
import { Reveal } from '@/components/Reveal'
import { Button } from '@/components/Button'
import { PageHero } from '@/components/PageHero'
import { ServiceIcon } from '@/components/ServiceIcon'
import { CtaSection } from '@/components/CtaSection'
import { IconCheckBrush, IconPhoneRing, IconDiamond } from '@/components/icons'

export default function Services() {
  const services = useContent(servicesByLang)
  const servicesIntro = useContent(servicesIntroByLang)
  const servicesSeo = useContent(servicesSeoByLang)
  const { path } = useLang()
  const t = useUi()
  return (
    <>
      <Seo title={servicesSeo.title} description={servicesSeo.description} />
      <PageHero eyebrow={servicesIntro.eyebrow} title={servicesIntro.title} subtitle={servicesIntro.subtitle}>
        <div className="flex flex-wrap gap-2.5">
          {services.map((s) => (
            <a
              key={s.key}
              href={`#${s.key}`}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-full border border-line bg-white px-4 py-2 text-sm font-medium text-espresso transition-colors hover:border-gold hover:text-gold-dark"
            >
              <ServiceIcon name={s.key} className="h-4 w-4 text-gold-deep" />
              {s.title}
            </a>
          ))}
        </div>
      </PageHero>

      {services.map((s, idx) => (
        <section
          key={s.key}
          id={s.key}
          className={cn('section scroll-mt-24', idx % 2 === 0 ? 'bg-cream' : 'bg-sand-light')}
        >
          <div className="container-x">
            <div className="grid items-center gap-12 lg:grid-cols-2">
              <Reveal className={cn(idx % 2 === 1 && 'lg:order-2')}>
                <div className="relative">
                  <img
                    {...imgSet(serviceImages[s.key], [384, 512, 720, 960])}
                    sizes="(min-width: 1024px) 50vw, 100vw"
                    alt={s.title}
                    className="aspect-[4/3] w-full rounded-3xl object-cover shadow-card"
                    decoding="async"
                    loading={idx === 0 ? 'eager' : 'lazy'}
                    fetchPriority={idx === 0 ? 'high' : undefined}
                  />
                  <span className="absolute -bottom-5 left-6 flex items-center gap-2.5 rounded-2xl bg-espresso px-4 py-3 text-cream shadow-soft">
                    <ServiceIcon name={s.key} className="h-6 w-6 text-gold-bright" />
                    <span className="font-display text-sm font-semibold">0{idx + 1} — {s.title}</span>
                  </span>
                </div>
              </Reveal>

              <div className={cn(idx % 2 === 1 && 'lg:order-1')}>
                <span className="eyebrow">{t.services.itemEyebrow} 0{idx + 1}</span>
                <h2 className="mt-4 font-display text-3xl font-semibold leading-tight text-espresso sm:text-4xl">{s.title}</h2>
                <p className="mt-3 text-lg font-medium text-gold-deep">{s.tagline}</p>
                <div className="mt-5 space-y-4">
                  {s.paragraphs.map((p, i) => (
                    <p key={i} className="leading-relaxed text-ink/80">{p}</p>
                  ))}
                </div>
              </div>
            </div>

            {/* Includes + benefits */}
            <div className="mt-12 grid gap-6 lg:grid-cols-2">
              <Reveal>
                <div className="h-full rounded-3xl border border-line bg-white p-7 shadow-soft">
                  <h3 className="font-display text-lg font-semibold text-espresso">{t.services.includedTitle}</h3>
                  <ul className="mt-5 grid gap-3 sm:grid-cols-2">
                    {s.includes.map((inc) => (
                      <li key={inc} className="flex items-start gap-2.5 text-[15px] text-ink/80">
                        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gold-50 text-gold-deep">
                          <IconCheckBrush className="h-3 w-3" />
                        </span>
                        {inc}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-6 rounded-2xl bg-sand-light p-4 text-sm text-ink/75">
                    <span className="font-semibold text-espresso">{t.services.idealForLabel} </span>
                    {s.idealFor}
                  </div>
                </div>
              </Reveal>

              <div className="grid gap-4 sm:grid-cols-2">
                {s.benefits.map((b, i) => (
                  <Reveal key={b.title} delay={i * 0.06}>
                    <div className="group h-full rounded-3xl border border-line bg-white p-6 shadow-soft transition-colors hover:border-gold/50">
                      <IconDiamond className="h-2 w-2 text-gold transition-transform duration-300 group-hover:rotate-90" />
                      <h4 className="mt-3 font-display text-base font-semibold text-espresso">{b.title}</h4>
                      <p className="mt-2 text-sm leading-relaxed text-ink/70">{b.text}</p>
                    </div>
                  </Reveal>
                ))}
              </div>
            </div>

            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <Button to={path('contact')} variant="primary" icon={<ArrowRight className="h-4 w-4" />}>
                {t.common.getQuoteForPrefix} {s.title.toLowerCase()}
              </Button>
              <Button href={`tel:${site.phoneRaw}`} variant="outline" icon={<IconPhoneRing className="h-4 w-4" />}>
                {site.phone}
              </Button>
            </div>
          </div>
        </section>
      ))}

      <CtaSection />
    </>
  )
}
