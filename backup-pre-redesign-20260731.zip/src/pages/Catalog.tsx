import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Info } from 'lucide-react'
import { IconRulerCraft, IconDrop } from '@/components/icons'
import { cn, formatIsk } from '@/lib/utils'
import { catalog as catalogByLang, catalogSeo as catalogSeoByLang } from '@/data/catalog'
import { useContent, useLang, useUi } from '@/i18n/context'
import { Seo } from '@/components/Seo'
import { Reveal } from '@/components/Reveal'
import { PageHero } from '@/components/PageHero'
import { ParquetSwatch } from '@/components/ParquetSwatch'
import { CtaSection } from '@/components/CtaSection'

export default function Catalog() {
  const catalog = useContent(catalogByLang)
  const catalogSeo = useContent(catalogSeoByLang)
  const { path } = useLang()
  const t = useUi()
  const [active, setActive] = useState<string>('all')
  const categoryLabel = (key: string) => catalog.categories.find((c) => c.key === key)?.label ?? key
  const visible = active === 'all' ? catalog.products : catalog.products.filter((p) => p.category === active)

  return (
    <>
      <Seo title={catalogSeo.title} description={catalogSeo.description} />
      <PageHero eyebrow={catalog.intro.eyebrow} title={catalog.intro.title} subtitle={catalog.intro.subtitle} />

      <section className="section bg-cream">
        <div className="container-x">
          {/* Filters */}
          <div className="flex flex-wrap gap-2.5">
            <FilterButton active={active === 'all'} onClick={() => setActive('all')}>
              {t.common.filterAll}
            </FilterButton>
            {catalog.categories.map((c) => (
              <FilterButton key={c.key} active={active === c.key} onClick={() => setActive(c.key)}>
                {c.label}
              </FilterButton>
            ))}
          </div>

          {/* Grid */}
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((p, i) => (
              <Reveal key={p.name} delay={(i % 3) * 0.07}>
                <article className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-line bg-white shadow-card transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_26px_60px_-24px_rgba(43,28,16,0.4)]">
                  <span className="absolute inset-x-0 top-0 z-10 h-0.5 origin-left scale-x-0 bg-gold transition-transform duration-300 group-hover:scale-x-100" aria-hidden />
                  <div className="relative h-44 overflow-hidden">
                    <ParquetSwatch tone={p.tone} pattern={p.pattern} className="h-full w-full transition-transform duration-700 group-hover:scale-105" />
                    {p.badge && (
                      <span className="absolute left-4 top-4 rounded-full bg-gold-deep px-3 py-1 text-xs font-semibold text-white shadow-gold">{p.badge}</span>
                    )}
                    <span className="absolute bottom-3 right-3 rounded-full bg-espresso/80 px-3 py-1 text-[11px] font-medium text-cream backdrop-blur-sm">
                      {categoryLabel(p.category)}
                    </span>
                  </div>

                  <div className="flex flex-1 flex-col p-6">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-display text-lg font-semibold text-espresso">{p.name}</h3>
                        <p className="mt-0.5 text-sm text-taupe">{p.woodTone}</p>
                      </div>
                      <div className="shrink-0 text-right">
                        <div className="font-display text-lg font-semibold tabular-nums text-gold-deep">{formatIsk(p.pricePerM2)}</div>
                        <div className="text-[11px] uppercase tracking-wide text-taupe">{t.common.perM2}</div>
                      </div>
                    </div>

                    <p className="mt-3 flex-1 text-sm leading-relaxed text-ink/70">{p.description}</p>

                    <div className="mt-4 flex flex-wrap gap-2">
                      <Chip icon={<IconRulerCraft className="h-3.5 w-3.5" />}>{p.thickness}</Chip>
                      <Chip icon={<IconDrop className="h-3.5 w-3.5" />}>{p.finish}</Chip>
                    </div>

                    <div className="mt-4 border-t border-line pt-4 text-sm text-ink/70">
                      <span className="font-semibold text-espresso">{t.catalog.bestForLabel} </span>
                      {p.bestFor}
                    </div>

                    <Link to={path('contact')} className="link-underline mt-4 text-sm">
                      {t.common.getQuote} <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>

          {/* Price note */}
          <Reveal className="mt-12">
            <div className="flex items-start gap-3 rounded-3xl border border-gold/30 bg-gold-50/50 p-6">
              <Info className="mt-0.5 h-5 w-5 shrink-0 text-gold-deep" />
              <p className="text-sm leading-relaxed text-ink/80">{catalog.intro.priceNote}</p>
            </div>
          </Reveal>
        </div>
      </section>

      <CtaSection title={t.catalog.ctaTitle} subtitle={t.catalog.ctaSubtitle} />
    </>
  )
}

function FilterButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'inline-flex min-h-[44px] items-center rounded-full border px-5 py-2.5 text-sm font-medium transition-colors',
        active ? 'border-gold-deep bg-gold-deep text-white' : 'border-line bg-white text-ink/75 hover:border-gold hover:text-gold-dark',
      )}
    >
      {children}
    </button>
  )
}

function Chip({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-sand-light px-3 py-1 text-xs font-medium text-walnut">
      <span className="text-gold-deep">{icon}</span>
      {children}
    </span>
  )
}
