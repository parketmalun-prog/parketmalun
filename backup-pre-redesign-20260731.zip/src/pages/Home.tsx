import { useState } from 'react'
import { Link } from 'react-router-dom'
import { m, AnimatePresence } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import { cn, imgSet } from '@/lib/utils'
import { site, serviceImages } from '@/data/site'
import { home as homeByLang } from '@/data/home'
import { useContent, useLang, useUi } from '@/i18n/context'
import { Seo } from '@/components/Seo'
import { Reveal } from '@/components/Reveal'
import { Button } from '@/components/Button'
import { SectionHeading } from '@/components/SectionHeading'
import { ServiceIcon } from '@/components/ServiceIcon'
import { BeforeAfter } from '@/components/BeforeAfter'
import { CtaSection } from '@/components/CtaSection'
import { Marquee } from '@/components/Marquee'
import { PlankEdge } from '@/components/PlankEdge'
import { Stat } from '@/components/Stat'
import {
  IconAward,
  IconTrowel,
  IconShieldPlank,
  IconSparkleStar,
  IconCheckBrush,
  IconPhoneRing,
  IconQuote,
  IconStarRate,
  IconDiamond,
} from '@/components/icons'

const whyIcons = [IconAward, IconTrowel, IconShieldPlank, IconSparkleStar]

export default function Home() {
  const home = useContent(homeByLang)
  const t = useUi()
  const { path } = useLang()
  const [ti, setTi] = useState(0)
  const featured = home.testimonials[ti]

  return (
    <>
      <Seo title={home.seo.title} description={home.seo.description} />

      {/* ============ HERO ============ */}
      <section className="grain relative isolate overflow-hidden bg-espresso">
        <img
          {...imgSet(home.heroImageId, [768, 1080, 1440, 1920])}
          sizes="100vw"
          alt={t.common.alt.hero}
          fetchPriority="high"
          decoding="async"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-espresso/95 via-espresso/80 to-espresso/30" aria-hidden />
        <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-transparent to-espresso/40" aria-hidden />

        <div className="container-x relative grid min-h-[calc(92svh-114px)] items-center gap-12 py-20 pb-32 lg:grid-cols-[1.15fr_0.85fr]">
          <div className="max-w-2xl">
            <Reveal>
              <span className="eyebrow text-gold-bright">{home.hero.eyebrow}</span>
            </Reveal>
            <Reveal delay={0.08}>
              <h1 className="mt-5 font-display text-4xl font-semibold leading-[1.06] tracking-tightish text-cream sm:text-5xl lg:text-[3.9rem]">
                {home.hero.titlePre}{' '}
                <em className="relative inline-block whitespace-normal font-display italic text-gold-bright sm:whitespace-nowrap">
                  {home.hero.titleAccent}
                  {/* hand-drawn brush underline */}
                  <svg
                    className="absolute -bottom-2 left-0 w-full"
                    viewBox="0 0 200 10"
                    preserveAspectRatio="none"
                    aria-hidden
                  >
                    <path
                      d="M3 7.5C58 2.5 142 2.5 197 7.5"
                      stroke="#CAA15C"
                      strokeWidth="3.4"
                      fill="none"
                      strokeLinecap="round"
                      opacity="0.9"
                    />
                  </svg>
                </em>{' '}
                {home.hero.titlePost}
              </h1>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-7 max-w-xl text-lg leading-relaxed text-cream/80">{home.hero.subtitle}</p>
            </Reveal>
            <Reveal delay={0.24}>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <Button to={path('contact')} variant="primary" size="lg" icon={<ArrowRight className="h-5 w-5" />}>
                  {home.hero.ctaPrimary}
                </Button>
                <Button href={`tel:${site.phoneRaw}`} variant="ghost-light" size="lg" icon={<IconPhoneRing className="h-5 w-5" />}>
                  {home.hero.ctaSecondary}
                </Button>
              </div>
            </Reveal>
            <Reveal delay={0.32}>
              <ul className="mt-10 flex flex-wrap gap-x-7 gap-y-3">
                {home.trustBar.map((t) => (
                  <li key={t} className="flex items-center gap-2 text-sm font-medium text-cream/85">
                    <IconCheckBrush className="h-4 w-4 text-gold-bright" />
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          {/* Floating credential cards */}
          <div className="hidden flex-col items-end gap-6 lg:flex">
            <Reveal delay={0.3}>
              <div className="w-72 -rotate-2 animate-float rounded-3xl border border-gold/35 bg-espresso-700 p-6 text-cream shadow-card">
                <div className="flex items-center gap-4">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gold-deep text-white">
                    <IconAward className="h-6 w-6" />
                  </span>
                  <div>
                    <div className="font-display text-2xl font-semibold">{t.home.credYears}</div>
                    <div className="text-xs uppercase tracking-wider text-cream/70">{t.home.credExperience}</div>
                  </div>
                </div>
                <div className="my-4 h-px bg-white/15" />
                <div className="flex items-center gap-3 text-sm text-cream/85">
                  <IconSparkleStar className="h-5 w-5 text-gold-bright" />
                  {t.home.credProjects}
                </div>
              </div>
            </Reveal>
            <Reveal delay={0.42}>
              <a
                href={`tel:${site.phoneRaw}`}
                className="block w-72 rotate-[1.5deg] rounded-3xl bg-cream p-6 text-espresso shadow-card transition-transform hover:-translate-y-1"
              >
                <div className="font-display text-lg font-semibold">{t.home.quoteCardTitle}</div>
                <p className="mt-1 text-sm text-ink/70">{t.home.quoteCardText}</p>
                <div className="mt-4 flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gold-50 text-gold-deep">
                    <IconPhoneRing className="h-5 w-5" />
                  </span>
                  <span className="font-display text-2xl font-semibold tracking-wide">{site.phone}</span>
                </div>
              </a>
            </Reveal>
          </div>
        </div>

        {/* ticker strip — solid so it renders matte from the very first paint */}
        <div className="absolute inset-x-0 bottom-0 border-t border-white/10 bg-espresso py-3.5 text-gold-bright/90">
          <Marquee items={t.home.marquee} />
        </div>
      </section>

      {/* signature parquet-board edge between hero and content */}
      <PlankEdge />

      {/* ============ SERVICES ============ */}
      <section className="section relative overflow-hidden bg-cream">
        <span
          className="pointer-events-none absolute -top-4 right-0 hidden select-none font-display text-[9rem] font-bold uppercase leading-none text-ghost lg:block"
          aria-hidden
        >
          {t.nav.services}
        </span>
        <div className="container-x relative">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <SectionHeading
              eyebrow={home.servicesIntro.eyebrow}
              title={home.servicesIntro.title}
              subtitle={home.servicesIntro.subtitle}
              align="left"
            />
            <Reveal delay={0.1}>
              <Link to={path('services')} className="link-underline mb-1 text-sm">
                {t.common.viewAllServices} <ArrowRight className="h-4 w-4" />
              </Link>
            </Reveal>
          </div>

          <div className="mt-14 grid gap-6 md:grid-cols-3 md:gap-5 lg:gap-6">
            {home.services.map((s, i) => (
              <div key={s.key} className={cn(i === 1 && 'md:translate-y-8')}>
                <Reveal delay={i * 0.08}>
                <article className="group relative flex h-full flex-col rounded-3xl border border-line bg-white shadow-card transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_26px_60px_-24px_rgba(43,28,16,0.4)]">
                  <div className="relative m-2.5 h-52 overflow-hidden rounded-2xl">
                    <img
                      {...imgSet(serviceImages[s.key], [320, 480, 640, 768])}
                      sizes="(min-width: 768px) 33vw, 100vw"
                      alt={s.title}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      decoding="async"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-espresso/55 to-transparent" aria-hidden />
                    <span className="absolute right-4 top-3.5 font-display text-xl font-semibold text-cream/95" aria-hidden>
                      0{i + 1}
                    </span>
                  </div>
                  {/* icon badge — sibling of the image wrapper so it is never clipped */}
                  <div className="relative flex flex-1 flex-col px-6 pb-6 pt-3">
                    <span className="absolute -top-8 left-6 z-10 flex h-14 w-14 items-center justify-center rounded-2xl bg-gold-deep text-white shadow-gold ring-4 ring-white">
                      <ServiceIcon name={s.key} className="h-7 w-7" />
                    </span>
                    <h3 className="mt-7 font-display text-xl font-semibold text-espresso">{s.title}</h3>
                    <p className="mt-3 flex-1 text-[15px] leading-relaxed text-ink/70">{s.short}</p>
                    <Link to={path('services', s.key)} className="link-underline mt-5 text-sm">
                      {t.common.readMore}
                      <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                    </Link>
                  </div>
                </article>
                </Reveal>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ BEFORE / AFTER ============ */}
      <section className="section pattern-herringbone-light bg-cream-dark">
        <div className="container-x grid items-center gap-12 lg:grid-cols-2">
          <div>
            <SectionHeading
              eyebrow={home.beforeAfter.eyebrow}
              title={home.beforeAfter.title}
              subtitle={home.beforeAfter.subtitle}
              align="left"
            />
            <ul className="mt-8 space-y-4">
              {t.home.beforeAfterBullets.map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gold-50 text-gold-deep">
                    <IconCheckBrush className="h-3.5 w-3.5" />
                  </span>
                  <span className="text-[15px] leading-relaxed text-ink/80">{item}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8">
              <Button to={path('portfolio')} variant="outline" icon={<ArrowRight className="h-4 w-4" />}>
                {t.common.viewMoreProjects}
              </Button>
            </div>
          </div>
          <Reveal delay={0.1}>
            <BeforeAfter beforeId={home.beforeAfter.beforeImageId} afterId={home.beforeAfter.afterImageId} />
            <p className="mt-3 text-center text-xs text-taupe">{t.home.beforeAfterCaption}</p>
          </Reveal>
        </div>
      </section>

      {/* ============ WHY US + STATS ============ */}
      <section className="section pattern-herringbone-dark relative overflow-hidden bg-espresso text-cream">
        <span
          className="pointer-events-none absolute bottom-2 right-0 hidden select-none font-display text-[8rem] font-bold uppercase leading-none text-ghost-dark xl:block"
          aria-hidden
        >
          {t.home.ghostExperience}
        </span>
        <div className="container-x relative grid items-center gap-14 lg:grid-cols-[0.9fr_1.1fr]">
          {/* Craftsman photo with offset gold frame */}
          <Reveal>
            <div className="relative mx-auto max-w-md">
              <div className="absolute -left-4 -top-4 h-full w-full rounded-3xl border-2 border-gold/40" aria-hidden />
              <img
                {...imgSet(home.craftsmanImageId, [384, 512, 768, 900])}
                sizes="(min-width: 1024px) 40vw, 90vw"
                alt={t.common.alt.craftsman}
                className="relative aspect-[4/5] w-full rounded-3xl object-cover shadow-card"
                decoding="async"
                loading="lazy"
              />
              <div className="absolute -bottom-6 -right-4 flex items-center gap-3 rounded-2xl bg-gold-deep px-5 py-4 text-white shadow-gold sm:-right-6">
                <IconAward className="h-7 w-7" />
                <div>
                  <div className="font-display text-xl font-semibold leading-none">{t.home.badgeYears}</div>
                  <div className="mt-1 text-[10px] uppercase tracking-[0.18em] text-white">{t.home.badgeInTrade}</div>
                </div>
              </div>
            </div>
          </Reveal>

          <div>
            <SectionHeading eyebrow={t.common.whyUsEyebrow} title={home.whyUs.title} subtitle={home.whyUs.subtitle} align="left" light />
            <div className="mt-10 grid gap-x-8 gap-y-7 sm:grid-cols-2">
              {home.whyUs.points.map((p, i) => {
                const Icon = whyIcons[i % whyIcons.length]
                return (
                  <Reveal key={p.title} delay={i * 0.07}>
                    <div className="group flex gap-4">
                      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-line-dark bg-white/[0.05] text-gold-bright transition-colors group-hover:bg-gold-deep group-hover:text-white">
                        <Icon className="h-6 w-6" />
                      </span>
                      <div>
                        <h3 className="font-display text-base font-semibold text-cream">{p.title}</h3>
                        <p className="mt-1.5 text-sm leading-relaxed text-cream/70">{p.text}</p>
                      </div>
                    </div>
                  </Reveal>
                )
              })}
            </div>
          </div>
        </div>

        {/* Animated stats */}
        <div className="container-x relative mt-16">
          <div className="grid grid-cols-3 divide-x divide-line-dark rounded-3xl border border-line-dark bg-white/[0.04] px-2 py-8 text-center backdrop-blur-sm sm:py-10">
            {home.stats.map((s) => (
              <Stat
                key={s.label}
                value={s.value}
                label={s.label}
                valueClassName="text-2xl text-gold-bright sm:text-4xl lg:text-5xl"
                labelClassName="mt-1.5 text-xs uppercase tracking-wider text-cream/65 sm:text-sm"
              />
            ))}
          </div>
        </div>
      </section>

      {/* ============ PROCESS ============ */}
      <section className="section bg-sand-light">
        <div className="container-x">
          <SectionHeading eyebrow={t.home.processEyebrow} title={home.process.title} subtitle={home.process.subtitle} />
          <div className="relative mt-16">
            {/* connecting dashed line */}
            <div className="absolute left-[10%] right-[10%] top-6 hidden border-t-2 border-dashed border-gold/30 lg:block" aria-hidden />
            <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4 lg:gap-6">
              {home.process.steps.map((step, i) => (
                <Reveal key={step.title} delay={i * 0.08}>
                  <div className="relative flex h-full flex-col items-center text-center lg:px-2">
                    {/* diamond step marker */}
                    <span className="relative z-10 flex h-12 w-12 items-center justify-center">
                      <span className="absolute inset-0 rotate-45 rounded-[10px] border-2 border-gold bg-cream shadow-soft" aria-hidden />
                      <span className="relative font-display text-lg font-semibold text-gold-deep">{i + 1}</span>
                    </span>
                    <span
                      className="pointer-events-none absolute -top-3 right-2 select-none font-display text-6xl font-bold text-espresso/[0.05]"
                      aria-hidden
                    >
                      0{i + 1}
                    </span>
                    <h3 className="mt-6 font-display text-lg font-semibold text-espresso">{step.title}</h3>
                    <p className="mt-2.5 text-sm leading-relaxed text-ink/70">{step.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ============ TESTIMONIALS — featured + selector ============ */}
      <section className="section relative overflow-hidden bg-cream">
        <IconQuote className="pointer-events-none absolute -top-8 left-6 h-48 w-48 text-gold/10" aria-hidden />
        <div className="container-x relative">
          <SectionHeading
            eyebrow={t.home.testimonialsEyebrow}
            title={t.home.testimonialsTitle}
            subtitle={t.home.testimonialsSubtitle}
          />
          <div className="mt-14 grid gap-6 lg:grid-cols-[1.25fr_1fr]">
            {/* Featured quote */}
            <Reveal>
              <div className="relative flex h-full flex-col rounded-3xl border border-line bg-white p-8 shadow-card sm:p-10">
                <IconQuote className="h-10 w-10 text-gold" />
                <AnimatePresence mode="wait">
                  <m.div
                    key={ti}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.3 }}
                    className="flex flex-1 flex-col"
                  >
                    <blockquote className="mt-5 flex-1 font-display text-xl leading-relaxed text-espresso sm:text-2xl">
                      “{featured.quote}”
                    </blockquote>
                    <figcaption className="mt-7 flex items-center gap-4 border-t border-line pt-6">
                      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gold-50 font-display text-lg font-semibold text-gold-deep">
                        {featured.name.charAt(0)}
                      </span>
                      <div>
                        <div className="font-display font-semibold text-espresso">{featured.name}</div>
                        <div className="flex items-center gap-2 text-sm text-taupe">
                          {featured.location}
                          <span className="flex gap-0.5 text-gold">
                            {Array.from({ length: 5 }).map((_, s) => (
                              <IconStarRate key={s} className="h-3.5 w-3.5" />
                            ))}
                          </span>
                        </div>
                      </div>
                    </figcaption>
                  </m.div>
                </AnimatePresence>
              </div>
            </Reveal>

            {/* Selector list */}
            <div className="flex flex-col gap-3">
              {home.testimonials.map((t, i) => (
                <Reveal key={t.name} delay={i * 0.06}>
                  <button
                    type="button"
                    onClick={() => setTi(i)}
                    aria-pressed={ti === i}
                    className={cn(
                      'w-full rounded-2xl border p-5 text-left transition-all duration-200',
                      ti === i
                        ? 'border-gold bg-gold-50/70 shadow-soft'
                        : 'border-line bg-white hover:-translate-y-0.5 hover:border-gold/50',
                    )}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <IconDiamond className={cn('h-2 w-2', ti === i ? 'text-gold-deep' : 'text-gold/40')} />
                        <span className="font-display font-semibold text-espresso">{t.name}</span>
                      </div>
                      <span className="text-xs text-taupe">{t.location}</span>
                    </div>
                    <p className="mt-2 line-clamp-2 pl-5 text-sm leading-relaxed text-ink/65">{t.quote}</p>
                  </button>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      <CtaSection title={home.ctaBand.title} subtitle={home.ctaBand.subtitle} imageId={home.ctaBand.imageId} />
    </>
  )
}
