import { privacy as privacyByLang } from '@/data/privacy'
import { useContent } from '@/i18n/context'
import { Seo } from '@/components/Seo'
import { PageHero } from '@/components/PageHero'
import { Reveal } from '@/components/Reveal'
import { IconDiamond } from '@/components/icons'

export default function Privacy() {
  const p = useContent(privacyByLang)
  return (
    <>
      <Seo title={p.seo.title} description={p.seo.description} />
      <PageHero eyebrow={p.eyebrow} title={p.title} subtitle={p.lead} />

      <section className="section bg-cream">
        <div className="container-x">
          <div className="mx-auto max-w-3xl">
            <p className="text-sm font-medium uppercase tracking-wide text-taupe">{p.updated}</p>

            <div className="mt-8 space-y-10">
              {p.sections.map((s, i) => (
                <Reveal key={s.heading} delay={Math.min(i * 0.04, 0.2)}>
                  <div className="rounded-3xl border border-line bg-white p-7 shadow-soft sm:p-8">
                    <h2 className="flex items-start gap-3 font-display text-xl font-semibold text-espresso">
                      <IconDiamond className="mt-2.5 h-2 w-2 shrink-0 text-gold" />
                      {s.heading}
                    </h2>
                    {s.paragraphs?.map((par, j) => (
                      <p key={j} className="mt-4 leading-relaxed text-ink/80">
                        {par}
                      </p>
                    ))}
                    {s.bullets && (
                      <ul className="mt-4 space-y-2.5">
                        {s.bullets.map((b) => (
                          <li key={b} className="flex items-start gap-3 text-[15px] leading-relaxed text-ink/80">
                            <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rotate-45 bg-gold" aria-hidden />
                            {b}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
