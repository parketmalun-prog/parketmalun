import { useState } from 'react'
import { cn, imgSet } from '@/lib/utils'
import { IconMapPinCraft } from '@/components/icons'
import type { ServiceKey } from '@/data/site'
import { projects as projectsByLang, portfolioIntro as portfolioIntroByLang, portfolioSeo as portfolioSeoByLang } from '@/data/portfolio'
import { useContent, useUi } from '@/i18n/context'
import { Seo } from '@/components/Seo'
import { Reveal } from '@/components/Reveal'
import { PageHero } from '@/components/PageHero'
import { CtaSection } from '@/components/CtaSection'

type Filter = 'all' | ServiceKey

const serviceColor: Record<ServiceKey, string> = {
  parket: 'bg-gold-50 text-gold-dark',
  slipun: 'bg-espresso/85 text-cream',
  malun: 'bg-sand-dark/50 text-walnut',
}

export default function Portfolio() {
  const projects = useContent(projectsByLang)
  const portfolioIntro = useContent(portfolioIntroByLang)
  const portfolioSeo = useContent(portfolioSeoByLang)
  const t = useUi()
  const [active, setActive] = useState<Filter>('all')

  const filters: { key: Filter; label: string }[] = [
    { key: 'all', label: t.common.filterAll },
    { key: 'parket', label: t.serviceNames.parket },
    { key: 'slipun', label: t.serviceNames.slipun },
    { key: 'malun', label: t.serviceNames.malun },
  ]
  const visible = active === 'all' ? projects : projects.filter((p) => p.service === active)

  return (
    <>
      <Seo title={portfolioSeo.title} description={portfolioSeo.description} />
      <PageHero eyebrow={portfolioIntro.eyebrow} title={portfolioIntro.title} subtitle={portfolioIntro.subtitle} />

      <section className="section bg-cream">
        <div className="container-x">
          <div className="flex flex-wrap gap-2.5">
            {filters.map((f) => (
              <button
                key={f.key}
                type="button"
                onClick={() => setActive(f.key)}
                aria-pressed={active === f.key}
                className={cn(
                  'inline-flex min-h-[44px] items-center rounded-full border px-5 py-2.5 text-sm font-medium transition-colors',
                  active === f.key ? 'border-gold-deep bg-gold-deep text-white' : 'border-line bg-white text-ink/75 hover:border-gold hover:text-gold-dark',
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {visible.map((p, i) => (
              <Reveal key={p.title} delay={(i % 3) * 0.08}>
                <article className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-line bg-white shadow-card transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_26px_60px_-24px_rgba(43,28,16,0.4)]">
                  {/* gold reveal line */}
                  <span className="absolute inset-x-0 top-0 z-10 h-0.5 origin-left scale-x-0 bg-gold transition-transform duration-300 group-hover:scale-x-100" aria-hidden />
                  <div className={cn('relative overflow-hidden', i % 3 === 1 ? 'h-64' : 'h-56')}>
                    <img
                      {...imgSet(p.imageId, [320, 480, 640, 800])}
                      sizes="(min-width: 1024px) 33vw, (min-width: 768px) 50vw, 100vw"
                      alt={p.title}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      decoding="async"
                      loading={i < 3 ? 'eager' : 'lazy'}
                      fetchPriority={i < 3 ? 'high' : undefined}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-espresso/40 to-transparent" aria-hidden />
                    <span className={cn('absolute left-4 top-4 rounded-full px-3 py-1 text-xs font-semibold', serviceColor[p.service] ?? 'bg-white text-espresso')}>
                      {t.serviceNames[p.service]}
                    </span>
                    <span className="absolute bottom-4 right-4 rounded-full bg-espresso/85 px-3 py-1 text-xs font-medium text-cream">{p.tag}</span>
                  </div>
                  <div className="flex flex-1 flex-col p-6">
                    <div className="flex items-center gap-1.5 text-xs font-medium text-taupe">
                      <IconMapPinCraft className="h-3.5 w-3.5 text-gold-deep" />
                      {p.location}
                    </div>
                    <h3 className="mt-2 font-display text-lg font-semibold text-espresso">{p.title}</h3>
                    <p className="mt-2.5 flex-1 text-sm leading-relaxed text-ink/70">{p.description}</p>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>

          <p className="mt-12 text-center text-sm text-taupe">{t.portfolio.note}</p>
        </div>
      </section>

      <CtaSection />
    </>
  )
}
