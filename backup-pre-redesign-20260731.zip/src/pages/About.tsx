import { imgSet } from '@/lib/utils'
import { site } from '@/data/site'
import { about as aboutByLang, aboutSeo as aboutSeoByLang } from '@/data/about'
import { home as homeByLang } from '@/data/home'
import { useContent, useUi } from '@/i18n/context'
import { Seo } from '@/components/Seo'
import { Reveal } from '@/components/Reveal'
import { SectionHeading } from '@/components/SectionHeading'
import { PageHero } from '@/components/PageHero'
import { FaqAccordion } from '@/components/FaqAccordion'
import { CtaSection } from '@/components/CtaSection'
import { Stat } from '@/components/Stat'
import {
  IconSparkleStar,
  IconAward,
  IconShieldPlank,
  IconTrowel,
  IconMapPinCraft,
  IconCheckBrush,
} from '@/components/icons'

const valueIcons = [IconSparkleStar, IconAward, IconShieldPlank, IconTrowel]

export default function About() {
  const about = useContent(aboutByLang)
  const aboutSeo = useContent(aboutSeoByLang)
  const home = useContent(homeByLang)
  const t = useUi()
  return (
    <>
      <Seo title={aboutSeo.title} description={aboutSeo.description} />
      <PageHero eyebrow={about.eyebrow} title={about.title} subtitle={about.lead} />

      {/* Story */}
      <section className="section bg-cream">
        <div className="container-x grid items-center gap-12 lg:grid-cols-2">
          <Reveal>
            <div className="relative">
              <div className="absolute -left-4 -top-4 hidden h-full w-full rounded-3xl border-2 border-gold/30 sm:block" aria-hidden />
              <img
                {...imgSet(about.aboutImageId, [384, 512, 768, 900])}
                sizes="(min-width: 1024px) 45vw, 100vw"
                alt={t.common.alt.floorLaid}
                className="relative aspect-[4/5] w-full rounded-3xl object-cover shadow-card sm:aspect-[4/3] lg:aspect-[4/5]"
                decoding="async"
                loading="lazy"
              />
              {/* craftsman collage photo */}
              <img
                {...imgSet(home.craftsmanImageId, [200, 320, 400])}
                sizes="176px"
                alt={t.common.alt.craftsman}
                className="absolute -bottom-8 -left-3 hidden w-36 rotate-[-3deg] rounded-2xl border-4 border-cream object-cover shadow-card sm:block lg:w-44"
                decoding="async"
                loading="lazy"
              />
              <div className="absolute -bottom-6 -right-4 rounded-3xl bg-gold-deep px-7 py-6 text-center text-white shadow-gold sm:-right-6">
                <div className="font-display text-4xl font-semibold">{home.stats[0].value}</div>
                <div className="mt-1 text-xs uppercase tracking-wider text-white">{home.stats[0].label}</div>
              </div>
            </div>
          </Reveal>
          <div>
            <span className="eyebrow">{t.about.storyEyebrow}</span>
            <h2 className="mt-4 font-display text-3xl font-semibold leading-tight text-espresso sm:text-4xl">
              {t.about.storyTitle}
            </h2>
            <div className="mt-6 space-y-4">
              {about.paragraphs.map((p, i) => (
                <p key={i} className="leading-relaxed text-ink/80">{p}</p>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section bg-sand-light">
        <div className="container-x">
          <SectionHeading eyebrow={t.about.valuesEyebrow} title={t.about.valuesTitle} subtitle={t.about.valuesSubtitle} />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {about.values.map((v, i) => {
              const Icon = valueIcons[i % valueIcons.length]
              return (
                <Reveal key={v.title} delay={i * 0.08}>
                  <div className="h-full rounded-3xl border border-line bg-white p-7 shadow-soft">
                    <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gold-50 text-gold-deep">
                      <Icon className="h-6 w-6" />
                    </span>
                    <h3 className="mt-5 font-display text-lg font-semibold text-espresso">{v.title}</h3>
                    <p className="mt-2.5 text-sm leading-relaxed text-ink/70">{v.text}</p>
                  </div>
                </Reveal>
              )
            })}
          </div>
        </div>
      </section>

      {/* Why choose + stats */}
      <section className="section bg-cream">
        <div className="container-x grid gap-12 lg:grid-cols-2">
          <div>
            <span className="eyebrow">{t.common.whyUsEyebrow}</span>
            <h2 className="mt-4 font-display text-3xl font-semibold leading-tight text-espresso sm:text-4xl">{t.about.whyTitle}</h2>
            <ul className="mt-8 space-y-5">
              {about.whyChoose.map((w) => (
                <li key={w.title} className="flex items-start gap-4">
                  <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gold-deep text-white">
                    <IconCheckBrush className="h-4 w-4" />
                  </span>
                  <div>
                    <h3 className="font-display text-base font-semibold text-espresso">{w.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-ink/70">{w.text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* Service area */}
          <Reveal delay={0.1}>
            <div className="pattern-herringbone-dark relative overflow-hidden rounded-3xl border border-line bg-gradient-to-br from-espresso to-espresso-700 p-8 text-cream shadow-card">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gold-deep text-white">
                <IconMapPinCraft className="h-6 w-6" />
              </span>
              <h3 className="mt-5 font-display text-2xl font-semibold text-cream">{about.serviceArea.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-cream/75">{about.serviceArea.text}</p>
              <div className="mt-6 flex flex-wrap gap-2">
                {about.serviceArea.areas.map((a) => (
                  <span key={a} className="rounded-full border border-line-dark bg-white/[0.06] px-3.5 py-1.5 text-sm text-cream/90">
                    {a}
                  </span>
                ))}
              </div>
              <div className="mt-8 grid grid-cols-3 gap-3 border-t border-line-dark pt-6 text-center">
                {home.stats.map((s) => (
                  <Stat
                    key={s.label}
                    value={s.value}
                    label={s.label}
                    valueClassName="text-2xl text-gold-bright sm:text-3xl"
                    labelClassName="mt-1 text-[11px] uppercase tracking-wide text-cream/60"
                  />
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* FAQ */}
      <section className="section bg-sand-light">
        <div className="container-x">
          <SectionHeading eyebrow={t.about.faqEyebrow} title={t.about.faqTitle} subtitle={t.about.faqSubtitle.replace('{phone}', site.phone)} />
          <div className="mt-12">
            <FaqAccordion items={about.faq} />
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  )
}
