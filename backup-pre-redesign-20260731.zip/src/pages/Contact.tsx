import { useState } from 'react'
import type { FormEvent } from 'react'
import { Mail, Globe, CheckCircle2, Send } from 'lucide-react'
import { IconPhoneRing, IconClockCraft, IconMapPinCraft, IconShieldPlank } from '@/components/icons'
import { Link } from 'react-router-dom'
import { site } from '@/data/site'
import { contact as contactByLang, contactSeo as contactSeoByLang } from '@/data/contact'
import { useContent, useLang, useUi } from '@/i18n/context'
import { Seo } from '@/components/Seo'
import { Reveal } from '@/components/Reveal'
import { PageHero } from '@/components/PageHero'

type Status = 'idle' | 'sending' | 'success' | 'mailto' | 'error'

export default function Contact() {
  const contact = useContent(contactByLang)
  const contactSeo = useContent(contactSeoByLang)
  const t = useUi()
  const { path } = useLang()
  const [status, setStatus] = useState<Status>('idle')
  const f = contact.form

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const formEl = e.currentTarget
    const data = new FormData(formEl)

    // Honeypot: silently drop bot submissions that filled the hidden field.
    if (data.get('_gotcha')) {
      setStatus('success')
      formEl.reset()
      return
    }

    if (!site.formspreeEndpoint) {
      // Fallback: open the visitor's email client with a prefilled message.
      // We cannot confirm the mail client actually opened or sent anything,
      // so we show distinct "please double-check" copy instead of a false
      // confirmed-success message, and keep the form filled in case it failed.
      const subject = encodeURIComponent(`${t.contact.mailtoSubjectPrefix} ${data.get('name') || ''}`)
      const body = encodeURIComponent(
        `${t.contact.mailtoName}: ${data.get('name') || ''}\n${t.contact.mailtoPhone}: ${data.get('phone') || ''}\n${t.contact.mailtoEmail}: ${data.get('email') || ''}\n${t.contact.mailtoService}: ${data.get('service') || ''}\n\n${data.get('message') || ''}`,
      )
      window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`
      setStatus('mailto')
      return
    }

    setStatus('sending')
    try {
      const res = await fetch(site.formspreeEndpoint, {
        method: 'POST',
        body: data,
        headers: { Accept: 'application/json' },
      })
      if (res.ok) {
        setStatus('success')
        formEl.reset()
      } else {
        setStatus('error')
      }
    } catch {
      setStatus('error')
    }
  }

  return (
    <>
      <Seo title={contactSeo.title} description={contactSeo.description} />
      <PageHero eyebrow={contact.eyebrow} title={contact.title} subtitle={contact.subtitle} />

      <section className="section bg-cream">
        <div className="container-x grid gap-10 lg:grid-cols-[1fr_1.15fr] lg:gap-14">
          {/* Info column */}
          <Reveal>
            <div className="flex flex-col gap-6">
              <div className="rounded-3xl border border-line bg-white p-7 shadow-soft">
                <h2 className="font-display text-xl font-semibold text-espresso">{contact.infoTitle}</h2>
                <div className="mt-6 space-y-2">
                  <InfoRow icon={<IconPhoneRing className="h-5 w-5" />} href={`tel:${site.phoneRaw}`} label={t.contact.labelPhone} value={site.phone} big />
                  <InfoRow icon={<Mail className="h-5 w-5" />} href={`mailto:${site.email}`} label={t.contact.labelEmail} value={site.email} />
                  <InfoRow icon={<Globe className="h-5 w-5" />} href={`https://${site.web}`} label={t.contact.labelWeb} value={site.web} external />
                  <InfoRow icon={<IconMapPinCraft className="h-5 w-5" />} label={t.contact.labelArea} value={t.contact.areaValue} />
                </div>
              </div>

              <div className="rounded-3xl border border-line bg-white p-7 shadow-soft">
                <h3 className="flex items-center gap-2.5 font-display text-lg font-semibold text-espresso">
                  <IconClockCraft className="h-5 w-5 text-gold-deep" />
                  {contact.hoursTitle}
                </h3>
                <ul className="mt-4 space-y-2 text-sm text-ink/75">
                  {contact.hours.map((h) => (
                    <li key={h} className="flex items-center justify-between gap-4 border-b border-line/70 pb-2 last:border-0 last:pb-0">
                      <span>{h.split(':')[0]}</span>
                      <span className="font-medium text-espresso">{h.split(':').slice(1).join(':').trim()}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-4 flex items-start gap-2 text-sm text-taupe">
                  <IconShieldPlank className="mt-0.5 h-4 w-4 shrink-0 text-gold-deep" />
                  {contact.responseNote}
                </p>
              </div>

              <a href={`tel:${site.phoneRaw}`} className="btn btn-lg btn-secondary w-full">
                <IconPhoneRing className="h-5 w-5" />
                {t.common.callNow}: {site.phone}
              </a>
            </div>
          </Reveal>

          {/* Form column */}
          <Reveal delay={0.1}>
            <div className="rounded-3xl border border-line bg-white p-7 shadow-card sm:p-9">
              {status === 'success' || status === 'mailto' ? (
                <div className="flex min-h-[420px] flex-col items-center justify-center text-center" role="status" aria-live="polite">
                  <span className="flex h-16 w-16 items-center justify-center rounded-full bg-gold-50 text-gold-deep">
                    <CheckCircle2 className="h-9 w-9" />
                  </span>
                  <h2 className="mt-6 font-display text-2xl font-semibold text-espresso">
                    {status === 'mailto' ? f.mailtoTitle : f.successTitle}
                  </h2>
                  <p className="mt-3 max-w-sm text-ink/70">{status === 'mailto' ? f.mailtoText : f.successText}</p>
                  <button type="button" onClick={() => setStatus('idle')} className="btn btn-md btn-outline mt-8">
                    {t.contact.sendAnother}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  {/* Honeypot field — invisible to humans, catches spam bots */}
                  <input
                    type="text"
                    name="_gotcha"
                    tabIndex={-1}
                    autoComplete="off"
                    aria-hidden="true"
                    className="absolute -left-[9999px] h-0 w-0 opacity-0"
                  />
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label={f.nameLabel} required>
                      <input name="name" type="text" required maxLength={120} autoComplete="name" placeholder={f.namePlaceholder} className={inputClass} />
                    </Field>
                    <Field label={f.phoneLabel} required>
                      <input name="phone" type="tel" required maxLength={24} autoComplete="tel" inputMode="tel" placeholder={f.phonePlaceholder} className={inputClass} />
                    </Field>
                  </div>
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label={f.emailLabel}>
                      <input name="email" type="email" maxLength={160} autoComplete="email" placeholder={f.emailPlaceholder} className={inputClass} />
                    </Field>
                    <Field label={f.serviceLabel}>
                      <select name="service" defaultValue="" className={inputClass}>
                        <option value="" disabled>
                          {t.contact.selectService}
                        </option>
                        {f.serviceOptions.map((o) => (
                          <option key={o} value={o}>
                            {o}
                          </option>
                        ))}
                      </select>
                    </Field>
                  </div>
                  <Field label={f.messageLabel} required>
                    <textarea name="message" required rows={5} maxLength={3000} placeholder={f.messagePlaceholder} className={`${inputClass} resize-none`} />
                  </Field>

                  {status === 'error' && (
                    <p className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700" role="alert">
                      {f.errorText}
                    </p>
                  )}

                  <button type="submit" disabled={status === 'sending'} className="btn btn-lg btn-primary w-full">
                    {status === 'sending' ? (
                      f.sendingLabel
                    ) : (
                      <>
                        {f.submitLabel}
                        <Send className="h-4 w-4" />
                      </>
                    )}
                  </button>
                  <p className="text-center text-xs leading-relaxed text-taupe">
                    {f.privacyNote}{' '}
                    <Link to={path('privacy')} className="underline underline-offset-2 transition-colors hover:text-gold-deep">
                      {t.footer.privacyLabel}
                    </Link>
                  </p>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}

const inputClass =
  'w-full rounded-xl border border-line bg-cream/50 px-4 py-3 text-[15px] text-ink outline-none transition-colors placeholder:text-taupe focus:border-gold focus:bg-white'

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-espresso">
        {label}
        {required && <span className="ml-0.5 text-gold-dark">*</span>}
      </span>
      {children}
    </label>
  )
}

function InfoRow({
  icon,
  label,
  value,
  href,
  external,
  big,
}: {
  icon: React.ReactNode
  label: string
  value: string
  href?: string
  external?: boolean
  big?: boolean
}) {
  const inner = (
    <div className="flex items-center gap-4 rounded-2xl px-2 py-2.5 transition-colors hover:bg-sand-light/70">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gold-50 text-gold-deep">{icon}</span>
      <div className="min-w-0">
        <div className="text-xs uppercase tracking-wide text-taupe">{label}</div>
        <div className={`truncate font-medium text-espresso ${big ? 'text-lg' : ''}`}>{value}</div>
      </div>
    </div>
  )
  if (href) {
    return (
      <a href={href} {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})} className="block">
        {inner}
      </a>
    )
  }
  return inner
}
