import { cn } from '@/lib/utils'

/**
 * Signature section divider: two staggered rows of parquet boards, like the
 * edge of a freshly laid floor. Deterministic pattern (no randomness) drawn
 * from the brand wood palette — a hand-crafted touch unique to this site.
 */
const TONES = ['#CBA36A', '#8A5A2E', '#B4813A', '#6E4A2C', '#C8A877', '#7C5734']
const WIDTHS = [132, 88, 148, 104, 72, 140, 96, 156, 116, 84, 128, 100]
const GAP = 5

function row(y: number, height: number, offset: number, toneShift: number) {
  const rects = []
  let x = -offset
  let i = 0
  while (x < 1200) {
    const w = WIDTHS[i % WIDTHS.length]
    rects.push(
      <rect
        key={`${y}-${i}`}
        x={x}
        y={y}
        width={w}
        height={height}
        rx={2}
        fill={TONES[(i + toneShift) % TONES.length]}
      />,
    )
    x += w + GAP
    i += 1
  }
  return rects
}

export function PlankEdge({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 1200 22"
      preserveAspectRatio="none"
      aria-hidden
      className={cn('block h-[14px] w-full sm:h-[18px]', className)}
    >
      {row(0, 9.5, 0, 0)}
      {row(12.5, 9.5, 71, 3)}
    </svg>
  )
}
