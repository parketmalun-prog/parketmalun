import { useCallback, useRef, useState } from 'react'
import { MoveHorizontal } from 'lucide-react'
import { cn, imgSet } from '@/lib/utils'

const BA_WIDTHS = [384, 512, 720, 960]
const BA_SIZES = '(min-width: 1024px) 45vw, 100vw'
import { useUi } from '@/i18n/context'

type Props = {
  /** Photo of the room BEFORE renovation (bare/worn floor). */
  beforeId: string
  /** Photo of the finished result. */
  afterId: string
  className?: string
}

/**
 * Interactive before/after comparison between two REAL, different photos —
 * an untouched room with a bare floor vs. the finished, furnished result.
 */
export function BeforeAfter({ beforeId, afterId, className }: Props) {
  const [pos, setPos] = useState(52)
  const ref = useRef<HTMLDivElement>(null)
  const dragging = useRef(false)
  const t = useUi()

  const update = useCallback((clientX: number) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const pct = ((clientX - rect.left) / rect.width) * 100
    setPos(Math.max(3, Math.min(97, pct)))
  }, [])

  return (
    <div
      ref={ref}
      className={cn(
        'relative aspect-[4/3] w-full select-none overflow-hidden rounded-3xl shadow-card focus-within:ring-2 focus-within:ring-gold focus-within:ring-offset-2 focus-within:ring-offset-cream',
        className,
      )}
      onPointerDown={(e) => {
        dragging.current = true
        ;(e.target as HTMLElement).setPointerCapture?.(e.pointerId)
        update(e.clientX)
      }}
      onPointerMove={(e) => dragging.current && update(e.clientX)}
      onPointerUp={() => (dragging.current = false)}
      onPointerLeave={() => (dragging.current = false)}
    >
      {/* AFTER — finished floor (base layer) */}
      <img
        {...imgSet(afterId, BA_WIDTHS)}
        sizes={BA_SIZES}
        alt={t.common.alt.beforeAfterAfter}
        className="absolute inset-0 h-full w-full object-cover"
        draggable={false}
        decoding="async"
        loading="lazy"
      />
      <span className="pointer-events-none absolute bottom-4 right-4 z-10 flex items-center gap-1.5 rounded-full bg-gold-deep px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-white shadow-gold">
        {t.common.after}
      </span>

      {/* BEFORE — bare room (clipped layer) */}
      <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
        <img
          {...imgSet(beforeId, BA_WIDTHS)}
          sizes={BA_SIZES}
          alt={t.common.alt.beforeAfterBefore}
          className="absolute inset-0 h-full w-full object-cover"
          draggable={false}
          decoding="async"
          loading="lazy"
        />
        <span className="pointer-events-none absolute bottom-4 left-4 rounded-full bg-espresso/90 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-cream">
          {t.common.before}
        </span>
      </div>

      {/* Divider + handle */}
      <div className="pointer-events-none absolute inset-y-0 z-10" style={{ left: `${pos}%` }}>
        <div className="absolute inset-y-0 -ml-px w-0.5 bg-cream/95 shadow-[0_0_0_1px_rgba(43,28,16,0.2)]" />
        <div className="absolute top-1/2 -ml-5 -mt-5 flex h-10 w-10 items-center justify-center rounded-full border-2 border-cream bg-gold-deep text-white shadow-gold">
          <MoveHorizontal className="h-5 w-5" />
        </div>
      </div>

      <label className="sr-only" htmlFor={`ba-${afterId}`}>
        {t.a11y.sliderCompare}
      </label>
      <input
        id={`ba-${afterId}`}
        type="range"
        min={3}
        max={97}
        value={pos}
        onChange={(e) => setPos(Number(e.target.value))}
        className="absolute inset-x-0 bottom-0 h-full w-full cursor-ew-resize opacity-0"
        aria-label={t.a11y.sliderCompare}
        aria-valuetext={t.a11y.sliderValueText.replace('{n}', String(Math.round(pos)))}
      />
    </div>
  )
}
