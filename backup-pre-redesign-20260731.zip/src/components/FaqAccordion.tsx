import { useState } from 'react'
import { Plus } from 'lucide-react'
import { cn } from '@/lib/utils'

type QA = { q: string; a: string }

export function FaqAccordion({ items }: { items: QA[] }) {
  const [open, setOpen] = useState<number | null>(0)
  return (
    <div className="mx-auto max-w-3xl divide-y divide-line overflow-hidden rounded-3xl border border-line bg-white">
      {items.map((item, i) => {
        const isOpen = open === i
        return (
          <div key={i}>
            <button
              type="button"
              onClick={() => setOpen(isOpen ? null : i)}
              className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left transition-colors hover:bg-sand-light/60"
              aria-expanded={isOpen}
            >
              <span className="font-display text-lg font-medium text-espresso">{item.q}</span>
              <span
                className={cn(
                  'flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line text-gold-deep transition-transform duration-300',
                  isOpen && 'rotate-45 border-gold bg-gold-50',
                )}
                aria-hidden
              >
                <Plus className="h-4 w-4" />
              </span>
            </button>
            <div
              className={cn(
                'grid transition-all duration-300 ease-out',
                isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0',
              )}
            >
              <div className="overflow-hidden">
                <p className="px-6 pb-6 leading-relaxed text-ink/75">{item.a}</p>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
