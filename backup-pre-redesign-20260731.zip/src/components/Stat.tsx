import { useEffect, useRef, useState } from 'react'
import { animate, useInView, useReducedMotion } from 'framer-motion'
import { cn } from '@/lib/utils'

type Props = {
  value: string // e.g. "25+", "1000+", "100%"
  label: string
  className?: string
  valueClassName?: string
  labelClassName?: string
}

/** Animated count-up stat. Falls back to the static value under reduced motion. */
export function Stat({ value, label, className, valueClassName, labelClassName }: Props) {
  const match = value.match(/^(\d+)(.*)$/)
  const target = match ? parseInt(match[1], 10) : 0
  const suffix = match ? match[2] : value
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-40px 0px' })
  const reduce = useReducedMotion()
  // `null` = the count-up has not started; we then display the real target so
  // a never-firing IntersectionObserver can never leave a "0+"/"0%" on screen.
  const [n, setN] = useState<number | null>(null)

  useEffect(() => {
    if (!inView || !match) return
    if (reduce) {
      setN(target)
      return
    }
    const controls = animate(0, target, {
      duration: 1.6,
      ease: 'easeOut',
      onUpdate: (v) => setN(Math.round(v)),
    })
    return () => controls.stop()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inView, reduce, target])

  const display = n === null ? target : n
  return (
    <div ref={ref} className={className}>
      <div className={cn('font-display font-semibold tabular-nums', valueClassName)}>
        {match ? display : ''}
        {suffix}
      </div>
      <div className={labelClassName}>{label}</div>
    </div>
  )
}
