import { useEffect, useRef } from 'react'
import { cn } from '@/lib/utils'
import { IconDiamond } from './icons'

type Props = { items: string[]; className?: string }

/**
 * Infinite horizontal ticker (two identical halves, translated -50%).
 * Each half repeats the item list several times so its width safely
 * exceeds even ultra-wide viewports — otherwise a blank gap sweeps
 * through on wide screens once the shorter track's edge is reached.
 * Duration scales with the repeat count to keep the scroll speed constant.
 * Decorative — hidden from screen readers; stops under reduced-motion
 * via the global animation kill-switch in index.css.
 */
const REPEAT = 4
const BASE_DURATION_S = 34

export function Marquee({ items, className }: Props) {
  const trackRef = useRef<HTMLDivElement>(null)

  // Pause the endless scroll while it is off-screen so it stops burning the
  // compositor/battery on the ~90% of the page where it isn't visible.
  // Defaults to running, so a never-firing observer can never freeze it.
  useEffect(() => {
    const el = trackRef.current
    if (!el || typeof IntersectionObserver === 'undefined') return
    const io = new IntersectionObserver(
      ([entry]) => {
        el.style.animationPlayState = entry.isIntersecting ? 'running' : 'paused'
      },
      { rootMargin: '100px' },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])

  return (
    <div className={cn('overflow-hidden', className)} aria-hidden>
      <div
        ref={trackRef}
        className="flex w-max animate-marquee"
        style={{ animationDuration: `${BASE_DURATION_S * REPEAT}s` }}
      >
        {[0, 1].map((half) => (
          <div key={half} className="flex shrink-0 items-center">
            {Array.from({ length: REPEAT }).map((_, r) =>
              items.map((t, i) => (
                <span key={`${r}-${i}`} className="flex items-center">
                  <span className="whitespace-nowrap px-6 font-display text-sm font-medium uppercase tracking-[0.28em] sm:text-base">
                    {t}
                  </span>
                  <IconDiamond className="h-2 w-2 text-gold" />
                </span>
              )),
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
