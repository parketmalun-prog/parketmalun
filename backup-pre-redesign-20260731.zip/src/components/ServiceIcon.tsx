import type { ServiceKey } from '@/data/site'
import { IconParquet, IconSander, IconRoller } from './icons'

/** Maps the three core services to the custom craft icon set. */
export function ServiceIcon({ name, className }: { name: ServiceKey; className?: string }) {
  if (name === 'parket') return <IconParquet className={className} />
  if (name === 'slipun') return <IconSander className={className} />
  return <IconRoller className={className} />
}
