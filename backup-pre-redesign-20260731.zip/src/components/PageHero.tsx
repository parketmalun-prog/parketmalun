import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { useLang, useUi } from '@/i18n/context'
import { Reveal } from './Reveal'
import { IconDiamond } from './icons'

type Props = {
  eyebrow: string
  title: string
  subtitle?: string
  /** Big outlined watermark word behind the hero (defaults to the eyebrow). */
  ghost?: string
  children?: ReactNode
}

export function PageHero({ eyebrow, title, subtitle, ghost, children }: Props) {
  const { path } = useLang()
  const t = useUi()
  return (
    <section className="pattern-herringbone-light relative overflow-hidden border-b border-line bg-gradient-to-b from-sand-light to-cream">
      {/* decorative gold glow */}
      <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-gold/10 blur-3xl" aria-hidden />
      {/* ghost watermark */}
      <span
        className="pointer-events-none absolute -bottom-6 right-0 hidden select-none font-display text-[8rem] font-bold uppercase leading-none text-ghost lg:block"
        aria-hidden
      >
        {ghost ?? eyebrow}
      </span>

      <div className="container-x relative py-14 sm:py-20 lg:py-24">
        <Reveal>
          {/* breadcrumb */}
          <nav aria-label={t.a11y.breadcrumb} className="mb-6 flex items-center gap-2.5 text-xs font-medium uppercase tracking-[0.16em] text-taupe">
            <Link to={path('home')} className="transition-colors hover:text-gold-dark">
              {t.nav.home}
            </Link>
            <IconDiamond className="h-1.5 w-1.5 text-gold/60" />
            <span className="text-gold-dark">{eyebrow}</span>
          </nav>

          <span className="eyebrow">{eyebrow}</span>
          <h1 className="mt-4 max-w-3xl font-display text-4xl font-semibold leading-[1.06] tracking-tightish text-espresso sm:text-5xl lg:text-[3.4rem]">
            {title}
          </h1>
          {subtitle && <p className="mt-5 max-w-2xl text-lg leading-relaxed text-ink/75">{subtitle}</p>}
          {children && <div className="mt-8">{children}</div>}
        </Reveal>
      </div>
    </section>
  )
}
