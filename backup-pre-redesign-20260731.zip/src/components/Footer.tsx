import { Link } from 'react-router-dom'
import { Mail, Globe, Facebook } from 'lucide-react'
import { site } from '@/data/site'
import { useLang, useUi } from '@/i18n/context'
import { Logo } from './Logo'
import { PlankEdge } from './PlankEdge'
import { IconPhoneRing, IconMapPinCraft, IconDiamond, IconClockCraft } from './icons'

export function Footer() {
  const year = new Date().getFullYear()
  const { path } = useLang()
  const t = useUi()

  const serviceLinks = [
    { to: path('services', 'parket'), label: t.serviceFull.parket },
    { to: path('services', 'slipun'), label: t.serviceFull.slipun },
    { to: path('services', 'malun'), label: t.serviceFull.malun },
    { to: path('catalog'), label: t.footer.linkCatalog },
  ]

  const companyLinks = [
    { to: path('about'), label: t.nav.about },
    { to: path('portfolio'), label: t.nav.portfolio },
    { to: path('services'), label: t.nav.services },
    { to: path('contact'), label: t.nav.contact },
  ]

  return (
    <footer className="relative overflow-hidden bg-espresso text-cream">
      {/* signature parquet-board edge */}
      <PlankEdge className="relative z-10" />
      {/* herringbone texture */}
      <div className="pattern-herringbone-dark pointer-events-none absolute inset-0" aria-hidden />

      <div className="container-x relative py-16 lg:py-20">
        {/* top row: brand + call block */}
        <div className="flex flex-col gap-8 border-b border-line-dark pb-12 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <Logo tone="dark" />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-cream/70">{t.footer.tagline}</p>
          </div>
          <a
            href={`tel:${site.phoneRaw}`}
            className="group flex w-fit items-center gap-4 rounded-3xl border border-line-dark bg-white/[0.04] px-6 py-5 transition-colors hover:border-gold/50"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gold-deep text-white transition-transform group-hover:scale-105">
              <IconPhoneRing className="h-6 w-6" />
            </span>
            <span>
              <span className="block text-[11px] uppercase tracking-[0.2em] text-cream/60">{t.common.callNow}</span>
              <span className="font-display text-2xl font-semibold text-gold-bright">{site.phone}</span>
            </span>
          </a>
        </div>

        <div className="grid gap-12 pt-12 lg:grid-cols-[1.2fr_1fr_1fr_1.3fr]">
          <div>
            <h3 className="font-display text-sm font-semibold uppercase tracking-[0.18em] text-gold-bright">{t.footer.hoursTitle}</h3>
            <ul className="mt-5 space-y-3 text-sm text-cream/70">
              <li className="flex items-center gap-3">
                <IconClockCraft className="h-4 w-4 shrink-0 text-gold-bright" />
                {t.footer.hoursWeek}
              </li>
              <li className="flex items-center gap-3">
                <IconClockCraft className="h-4 w-4 shrink-0 text-gold-bright opacity-60" />
                {t.footer.hoursWeekend}
              </li>
            </ul>
            <div className="mt-6 flex items-center gap-3">
              <a
                href={site.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-line-dark text-cream/80 transition-colors hover:border-gold hover:text-gold-bright"
              >
                <Facebook className="h-[18px] w-[18px]" />
              </a>
            </div>
          </div>

          <FooterCol title={t.nav.services}>
            {serviceLinks.map((l) => (
              <FooterLink key={l.to} to={l.to} label={l.label} />
            ))}
          </FooterCol>

          <FooterCol title={t.footer.colCompany}>
            {companyLinks.map((l) => (
              <FooterLink key={l.to} to={l.to} label={l.label} />
            ))}
          </FooterCol>

          <FooterCol title={t.footer.colContact}>
            <ContactRow icon={<IconPhoneRing className="h-4 w-4" />} href={`tel:${site.phoneRaw}`} text={site.phone} />
            <ContactRow icon={<Mail className="h-4 w-4" />} href={`mailto:${site.email}`} text={site.email} />
            <ContactRow icon={<Globe className="h-4 w-4" />} href={`https://${site.web}`} text={site.web} external />
            <li className="flex items-start gap-3 pt-1 text-sm text-cream/70">
              <IconMapPinCraft className="mt-0.5 h-4 w-4 shrink-0 text-gold-bright" />
              <span>{t.footer.areaLine}</span>
            </li>
          </FooterCol>
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-3 border-t border-line-dark pt-6 text-sm text-cream/55 sm:flex-row sm:items-center">
          <p className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
            © {year} {site.legalName} — {t.footer.rights}
            <IconDiamond className="h-1.5 w-1.5 text-gold/50" aria-hidden />
            <Link to={path('privacy')} className="underline-offset-4 transition-colors hover:text-gold-bright hover:underline">
              {t.footer.privacyLabel}
            </Link>
          </p>
          <p className="flex items-center gap-2.5 text-gold-bright/80">
            {t.footer.badges[0]} <IconDiamond className="h-1.5 w-1.5" /> {t.footer.badges[1]} <IconDiamond className="h-1.5 w-1.5" /> {t.footer.badges[2]}
          </p>
        </div>
      </div>
    </footer>
  )
}

function FooterCol({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="font-display text-sm font-semibold uppercase tracking-[0.18em] text-gold-bright">{title}</h3>
      <ul className="mt-5 space-y-3">{children}</ul>
    </div>
  )
}

function FooterLink({ to, label }: { to: string; label: string }) {
  return (
    <li>
      <Link
        to={to}
        className="group flex items-center gap-2.5 text-sm text-cream/70 transition-colors hover:text-gold-bright"
      >
        <IconDiamond className="h-1.5 w-1.5 text-gold/50 transition-colors group-hover:text-gold-bright" />
        {label}
      </Link>
    </li>
  )
}

function ContactRow({ icon, href, text, external }: { icon: React.ReactNode; href: string; text: string; external?: boolean }) {
  return (
    <li>
      <a
        href={href}
        {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
        className="flex items-center gap-3 text-sm text-cream/70 transition-colors hover:text-gold-bright"
      >
        <span className="text-gold-bright">{icon}</span>
        {text}
      </a>
    </li>
  )
}
