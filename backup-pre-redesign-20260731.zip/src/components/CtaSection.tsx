import { ArrowRight } from 'lucide-react'
import { imgSet } from '@/lib/utils'
import { site } from '@/data/site'
import { useLang, useUi } from '@/i18n/context'
import { Reveal } from './Reveal'
import { Button } from './Button'
import { IconPhoneRing } from './icons'

type Props = {
  title?: string
  subtitle?: string
  imageId?: string
}

export function CtaSection({ title, subtitle, imageId = '1600585154340-be6161a56a0c' }: Props) {
  const { path } = useLang()
  const t = useUi()
  return (
    <section className="section">
      <div className="container-x">
        <Reveal className="relative overflow-hidden rounded-4xl bg-espresso">
          <img
            {...imgSet(imageId, [768, 1080, 1440], 55)}
            sizes="100vw"
            alt=""
            aria-hidden
            decoding="async"
            className="absolute inset-0 h-full w-full object-cover opacity-25"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-espresso via-espresso/90 to-espresso/50" aria-hidden />
          <div className="pattern-herringbone-dark absolute inset-0" aria-hidden />
          {/* gold hairlines */}
          <div className="absolute inset-x-10 top-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" aria-hidden />
          <div className="absolute inset-x-10 bottom-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" aria-hidden />

          <div className="relative flex flex-col items-start gap-8 p-9 sm:p-12 lg:flex-row lg:items-center lg:justify-between lg:p-16">
            <div className="max-w-xl">
              <span className="eyebrow text-gold-bright">{t.nav.contact}</span>
              <h2 className="mt-4 font-display text-3xl font-semibold leading-tight text-cream sm:text-4xl">{title ?? t.cta.defaultTitle}</h2>
              <p className="mt-4 text-lg leading-relaxed text-cream/75">{subtitle ?? t.cta.defaultSubtitle}</p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row lg:flex-col xl:flex-row">
              <Button to={path('contact')} variant="primary" size="lg" icon={<ArrowRight className="h-5 w-5" />}>
                {t.common.freeQuote}
              </Button>
              <Button href={`tel:${site.phoneRaw}`} variant="ghost-light" size="lg" icon={<IconPhoneRing className="h-5 w-5" />}>
                {site.phone}
              </Button>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
