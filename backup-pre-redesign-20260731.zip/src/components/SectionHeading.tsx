import { cn } from '@/lib/utils'
import { Reveal } from './Reveal'
import { IconDiamond } from './icons'

type Props = {
  eyebrow?: string
  title: string
  subtitle?: string
  align?: 'center' | 'left'
  light?: boolean
  className?: string
}

export function SectionHeading({ eyebrow, title, subtitle, align = 'center', light = false, className }: Props) {
  return (
    <Reveal className={cn(align === 'center' ? 'mx-auto max-w-2xl text-center' : 'max-w-2xl', className)}>
      {eyebrow && (
        <span className={cn('eyebrow', align === 'center' && 'justify-center')}>{eyebrow}</span>
      )}
      <h2
        className={cn(
          'mt-4 font-display text-3xl font-semibold leading-tight tracking-tightish sm:text-4xl lg:text-[2.6rem]',
          light ? 'text-cream' : 'text-espresso',
        )}
      >
        {title}
      </h2>
      {/* diamond + lines ornament */}
      <span
        className={cn(
          'mt-5 flex items-center gap-2.5 text-gold',
          align === 'center' ? 'justify-center' : 'justify-start',
        )}
        aria-hidden
      >
        <span className={cn('h-px w-10', light ? 'bg-gold/40' : 'bg-gold/50')} />
        <IconDiamond className="h-2 w-2" />
        <span className={cn('h-px w-10', light ? 'bg-gold/40' : 'bg-gold/50')} />
      </span>
      {subtitle && (
        <p className={cn('mt-4 text-base leading-relaxed sm:text-lg', light ? 'text-cream/75' : 'text-ink/75')}>
          {subtitle}
        </p>
      )}
    </Reveal>
  )
}
