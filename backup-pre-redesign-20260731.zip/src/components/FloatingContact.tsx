import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import { site } from '@/data/site'
import { useUi } from '@/i18n/context'
import { IconPhoneRing } from './icons'

/** Floating call button that appears after the user scrolls past the hero. */
export function FloatingContact() {
  const [show, setShow] = useState(false)
  const t = useUi()
  useEffect(() => {
    const onScroll = () => {
      const scrolledPastHero = window.scrollY > 480
      // Hide near the very bottom so the pill doesn't cover the footer's own
      // phone/email/privacy links (they sit right where mobile users land).
      const nearBottom = window.innerHeight + window.scrollY >= document.body.scrollHeight - 140
      setShow(scrolledPastHero && !nearBottom)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
    }
  }, [])

  return (
    <a
      href={`tel:${site.phoneRaw}`}
      aria-label={`${t.common.callPrefix} ${site.phone}`}
      aria-hidden={!show}
      tabIndex={show ? 0 : -1}
      className={cn(
        'group fixed bottom-5 right-5 z-40 flex items-center gap-2.5 rounded-full bg-gold-deep py-3.5 pl-3.5 pr-5 text-white shadow-gold transition-all duration-300 hover:bg-gold-dark sm:bottom-7 sm:right-7',
        show ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-4 opacity-0',
      )}
    >
      <span className="relative flex h-6 w-6 items-center justify-center">
        {/* only animate the ping while the button is actually on screen */}
        {show && (
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white/40 [animation-duration:2s]" aria-hidden />
        )}
        <IconPhoneRing className="h-5 w-5" />
      </span>
      <span className="text-[15px] font-semibold">{site.phone}</span>
    </a>
  )
}
