import { useEffect, useRef, useState } from 'react'
import { m, useInView, useReducedMotion } from 'framer-motion'
import type { ReactNode } from 'react'

type RevealProps = {
  children: ReactNode
  className?: string
  delay?: number
  y?: number
}

/**
 * Fade + rise into view on scroll — progressive enhancement.
 *
 * The content is NEVER hard-hidden behind a single IntersectionObserver
 * callback: under reduced-motion it renders plainly, and a mount-time safety
 * net force-reveals anything already in the initial viewport if the observer
 * has not reported it shortly after (flaky low-end webviews, embedded panes
 * and fast-scroll races can otherwise leave the hero H1 / whole sections
 * stuck at opacity:0). Off-screen content still waits for the scroll reveal.
 */
export function Reveal({ children, className, delay = 0, y = 24 }: RevealProps) {
  const reduce = useReducedMotion()
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-60px 0px' })
  const [failsafe, setFailsafe] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    // No IntersectionObserver at all → reveal immediately.
    if (typeof IntersectionObserver === 'undefined') {
      setFailsafe(true)
      return
    }
    // Anything visible at first paint must appear even if the observer never
    // fires; below-the-fold content is left to the normal scroll reveal.
    const id = window.setTimeout(() => {
      const r = el.getBoundingClientRect()
      const inViewport = r.top < window.innerHeight && r.bottom > 0
      if (inViewport) setFailsafe(true)
    }, 500)
    return () => window.clearTimeout(id)
  }, [])

  // Reduced motion: render statically, fully visible, no observer dependency.
  if (reduce) {
    return (
      <div ref={ref} className={className}>
        {children}
      </div>
    )
  }

  const shown = inView || failsafe
  return (
    <m.div
      ref={ref}
      className={className}
      initial={{ opacity: 0, y }}
      animate={shown ? { opacity: 1, y: 0 } : { opacity: 0, y }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </m.div>
  )
}
