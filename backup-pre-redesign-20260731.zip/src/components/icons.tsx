/**
 * Custom "craft" icon set for Expert Parket og Mál — drawn by hand for this
 * brand, NOT a standard library. Shared visual language:
 *  - 24×24 grid, 1.7px rounded strokes
 *  - every icon carries a small filled "diamond spark" signature
 *  - secondary strokes at 50% opacity for a two-tone, engraved feel
 */
type IconProps = { className?: string }

const base = {
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
  'aria-hidden': true,
}

/** Herringbone chevrons — parquet laying. */
export function IconParquet({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M4 9.5 12 5l8 4.5" />
      <path d="M4 14.5 12 10l8 4.5" opacity="0.5" />
      <path d="M4 19.5 12 15l8 4.5" />
      <path d="M12 1.9l1.2 1.2L12 4.3l-1.2-1.2z" fill="currentColor" stroke="none" />
    </svg>
  )
}

/** Floor sanding machine with polish sparks. */
export function IconSander({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <rect x="4.4" y="12" width="8.2" height="5.6" rx="1.3" />
      <circle cx="7" cy="19.4" r="1.5" />
      <path d="M12.6 12 19 5.2" />
      <path d="M17.6 3.6l2.8 2.8" />
      <path d="M15.6 20.6h2.4M19.8 20.6h1" opacity="0.5" />
      <path d="M3 20.6h9.6" />
      <path d="M15 8.4l1.1 1.1L15 10.6l-1.1-1.1z" fill="currentColor" stroke="none" />
    </svg>
  )
}

/** Paint roller with a wavy fresh-paint stripe. */
export function IconRoller({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <rect x="4.4" y="4.4" width="11.2" height="4.8" rx="2" />
      <path d="M15.6 6.8h3v4.4h-5.2v2.4" />
      <path d="M13.4 13.6v3" />
      <rect x="11.8" y="16.6" width="3.2" height="3.6" rx="1" />
      <path d="M5.4 11.6c3.4 1.3 7.2 1.3 10.2 0" opacity="0.5" />
      <path d="M7.4 13.4l1.1 1.1-1.1 1.1-1.1-1.1z" fill="currentColor" stroke="none" />
    </svg>
  )
}

/** Trowel — preparation & craft. */
export function IconTrowel({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M4.2 4.2l9.6 2-7.6 7.6-2-9.6z" />
      <path d="M6.6 6.4l4.4.9" opacity="0.5" />
      <path d="M11.4 10.6l2.2 2.2" />
      <path d="M13.6 12.8l4.4 4.4" strokeWidth="2.4" />
      <path d="M19.6 18.4l1.1 1.1-1.1 1.1-1.1-1.1z" fill="currentColor" stroke="none" />
    </svg>
  )
}

/** Lacquer / oil drop with sheen. */
export function IconDrop({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M12 3.4c3.2 3.9 5.4 6.4 5.4 9.3a5.4 5.4 0 1 1-10.8 0c0-2.9 2.2-5.4 5.4-9.3z" />
      <path d="M9.5 13.2a2.7 2.7 0 0 0 1.9 2.5" opacity="0.5" />
      <path d="M17.8 5.4l1.1 1.1-1.1 1.1-1.1-1.1z" fill="currentColor" stroke="none" />
    </svg>
  )
}

/** Shield with herringbone floor inside — guarantee. */
export function IconShieldPlank({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M12 2.8l7 2.8v5.5c0 4.4-2.9 7.4-7 9.4-4.1-2-7-5-7-9.4V5.6l7-2.8z" />
      <path d="M8.6 12.4 12 10l3.4 2.4" />
      <path d="M8.6 15.6 12 13.2l3.4 2.4" opacity="0.5" />
    </svg>
  )
}

/** Clock with gold hour ticks — punctuality. */
export function IconClockCraft({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <circle cx="12" cy="12.6" r="7.9" />
      <path d="M12 8.4v4.2l2.9 1.9" />
      <path d="M12 6.2v-1M18.4 12.6h1" opacity="0.5" />
      <path d="M12 1.6l1 1-1 1-1-1z" fill="currentColor" stroke="none" />
    </svg>
  )
}

/** Four-point sparkle — clean finish / quality. */
export function IconSparkleStar({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M11.2 3.2c.8 4 2.6 5.8 6.6 6.6-4 .8-5.8 2.6-6.6 6.6-.8-4-2.6-5.8-6.6-6.6 4-.8 5.8-2.6 6.6-6.6z" />
      <path d="M18.4 15.4l.7 1.9 1.9.7-1.9.7-.7 1.9-.7-1.9-1.9-.7 1.9-.7.7-1.9z" fill="currentColor" stroke="none" opacity="0.55" />
    </svg>
  )
}

/** Medal with herringbone chevron — 25+ years of experience. */
export function IconAward({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <circle cx="12" cy="9" r="5.2" />
      <path d="M9.4 8.9 12 7l2.6 1.9" opacity="0.5" />
      <path d="M9.3 13.3 7.6 20.6l4.4-2.5 4.4 2.5-1.7-7.3" />
    </svg>
  )
}

/** Ringing handset. */
export function IconPhoneRing({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M5.2 3.6h1.5c.7 0 1.3.5 1.4 1.2l.6 2.7c.1.6-.1 1.2-.6 1.6l-1.1 1a12.4 12.4 0 0 0 5.9 5.9l1-1.1c.4-.5 1-.7 1.6-.6l2.7.6c.7.1 1.2.7 1.2 1.4v1.5c0 .8-.7 1.5-1.5 1.4C10.5 18.7 5.3 13.5 3.8 5.1c-.1-.8.6-1.5 1.4-1.5z" />
      <path d="M14.6 5.6a4.6 4.6 0 0 1 3.4 3.4" opacity="0.5" />
      <path d="M15.4 2.6a7.8 7.8 0 0 1 5.6 5.6" opacity="0.5" />
    </svg>
  )
}

/** Map pin with chevron floor inside. */
export function IconMapPinCraft({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M12 21.2s-6.6-5.5-6.6-10.2a6.6 6.6 0 1 1 13.2 0c0 4.7-6.6 10.2-6.6 10.2z" />
      <path d="M9.2 11.4 12 9.4l2.8 2" opacity="0.7" />
    </svg>
  )
}

/** Chunky serif quotes (filled). */
export function IconQuote({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden fill="currentColor">
      <path d="M9.8 6.6c-3 .7-4.9 2.8-4.9 6v4.8h5.4v-5.2H7.6c.1-1.9 1.2-3.1 3.1-3.7l-.9-1.9zm9 0c-3 .7-4.9 2.8-4.9 6v4.8h5.4v-5.2h-2.7c.1-1.9 1.2-3.1 3.1-3.7l-.9-1.9z" />
    </svg>
  )
}

/** Plump rating star (filled, rounded joins). */
export function IconStarRate({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden fill="currentColor" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round">
      <path d="M12 3.8l2.1 4.5 4.9.6-3.6 3.4 1 4.8L12 14.7l-4.4 2.4 1-4.8-3.6-3.4 4.9-.6L12 3.8z" />
    </svg>
  )
}

/** Small rotated-square diamond (filled) — separators & bullets. */
export function IconDiamond({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden fill="currentColor">
      <path d="M12 4.5 19.5 12 12 19.5 4.5 12z" />
    </svg>
  )
}

/** Brush-stroke check. */
export function IconCheckBrush({ className }: IconProps) {
  return (
    <svg {...base} className={className} strokeWidth={2.1}>
      <path d="M4.4 12.8c2 .9 3.6 2.4 4.6 4.3C11.4 12.2 15 8.3 19.6 5.8" />
    </svg>
  )
}

/** Diagonal ruler with ticks — precision / thickness. */
export function IconRulerCraft({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M3.4 16.6 16.6 3.4l4 4L7.4 20.6l-4-4z" />
      <path d="M7.2 12.8l1.5 1.5M10.2 9.8l1.5 1.5M13.2 6.8l1.5 1.5" opacity="0.6" />
    </svg>
  )
}

/** Stacked planks with offset joints — flooring material. */
export function IconPlanks({ className }: IconProps) {
  return (
    <svg {...base} className={className}>
      <path d="M4 7.7h16M4 12.2h16M4 16.7h16" />
      <path d="M10 7.7v4.5M14.5 12.2v4.5M7.5 3.2v4.5" opacity="0.5" />
      <path d="M4 3.2h16" opacity="0.5" />
    </svg>
  )
}
