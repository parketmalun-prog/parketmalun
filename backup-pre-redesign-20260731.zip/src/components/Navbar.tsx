import { useEffect, useRef, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { Menu, X, Facebook, Mail } from 'lucide-react'
import { cn } from '@/lib/utils'
import { site } from '@/data/site'
import { NAV_KEYS } from '@/i18n/config'
import { useLang, useUi } from '@/i18n/context'
import { LanguageSwitcher } from '@/i18n/LanguageSwitcher'
import { Logo } from './Logo'
import { IconPhoneRing, IconClockCraft } from './icons'

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const location = useLocation()
  const mobileMenuRef = useRef<HTMLDivElement>(null)
  const { path } = useLang()
  const t = useUi()

  const navItems = NAV_KEYS.map((key) => ({ key, label: t.nav[key], to: path(key) }))

  // Set the `inert` DOM property directly (imperatively) rather than as a
  // JSX prop: this React version's DOM attribute config doesn't recognize
  // `inert` as boolean, which would render `inert="false"` — an HTML
  // boolean attribute whose mere presence (any value) always applies.
  useEffect(() => {
    if (mobileMenuRef.current) mobileMenuRef.current.inert = !open
  }, [open])

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setOpen(false)
  }, [location.pathname])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  // Auto-close the mobile menu (and release the scroll lock) if the
  // viewport crosses into the desktop breakpoint while it's open.
  useEffect(() => {
    if (!open) return
    const mq = window.matchMedia('(min-width: 1024px)')
    const onChange = () => {
      if (mq.matches) setOpen(false)
    }
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [open])

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-all duration-300',
        // backdrop-blur is reserved for lg+ — repainting a blur behind a
        // full-width fixed bar every scroll frame is a top mobile-GPU cost.
        scrolled || open
          ? 'border-b border-line bg-cream/95 shadow-soft lg:backdrop-blur-md'
          : 'border-b border-transparent bg-cream/95 lg:bg-cream/85 lg:backdrop-blur',
      )}
    >
      {/* Top utility bar — collapses away on scroll */}
      <div
        className={cn(
          'hidden overflow-hidden bg-espresso text-cream/75 transition-all duration-300 md:block',
          scrolled ? 'max-h-0' : 'max-h-10',
        )}
      >
        <div className="container-x flex h-10 items-center justify-between text-xs">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-2">
              <IconClockCraft className="h-3.5 w-3.5 text-gold-bright" />
              {t.topbar.hours}
            </span>
            <a
              href={`mailto:${site.email}`}
              className="hidden items-center gap-2 transition-colors hover:text-gold-bright lg:flex"
            >
              <Mail className="h-3.5 w-3.5 text-gold-bright" />
              {site.email}
            </a>
          </div>
          <div className="flex items-center gap-5">
            <span className="text-[10px] font-semibold uppercase tracking-[0.22em] text-gold-bright/90">
              {t.topbar.experience}
            </span>
            <a
              href={site.facebook}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
              className="transition-colors hover:text-gold-bright"
            >
              <Facebook className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Main bar */}
      <div className="container-x flex h-[74px] items-center justify-between gap-4">
        <Link to={path('home')} aria-label={t.a11y.logoHome} className="shrink-0">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label={t.a11y.menuMain}>
          {navItems.map((item) => (
            <NavLink
              key={item.key}
              to={item.to}
              end={item.key === 'home'}
              className={({ isActive }) =>
                cn(
                  'relative rounded-full px-3.5 py-2 text-[15px] font-medium transition-colors',
                  isActive ? 'text-gold-deep' : 'text-ink/80 hover:text-espresso',
                )
              }
            >
              {({ isActive }) => (
                <>
                  {item.label}
                  {isActive && (
                    <span
                      className="absolute -bottom-0.5 left-1/2 h-1.5 w-1.5 -translate-x-1/2 rotate-45 bg-gold"
                      aria-hidden
                    />
                  )}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2.5">
          <LanguageSwitcher variant="bar" className="hidden sm:block" />
          <a
            href={`tel:${site.phoneRaw}`}
            className="btn btn-md btn-primary hidden sm:inline-flex"
            aria-label={`${t.common.callPrefix} ${site.phone}`}
          >
            <IconPhoneRing className="h-4 w-4" />
            {site.phone}
          </a>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-espresso/15 text-espresso lg:hidden"
            aria-label={open ? t.a11y.closeMenu : t.a11y.openMenu}
            aria-expanded={open}
            aria-controls="farsima-valmynd"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu — inert while closed so its links leave the tab order
          and accessibility tree, not just the visible viewport. */}
      <div
        id="farsima-valmynd"
        ref={mobileMenuRef}
        className={cn(
          'overflow-hidden border-t border-line bg-cream transition-[max-height] duration-300 lg:hidden',
          open ? 'max-h-[640px]' : 'max-h-0',
        )}
      >
        <nav className="container-x flex flex-col gap-1 py-4" aria-label={t.a11y.menuMobile}>
          {navItems.map((item) => (
            <NavLink
              key={item.key}
              to={item.to}
              end={item.key === 'home'}
              className={({ isActive }) =>
                cn(
                  'rounded-xl px-4 py-3 text-base font-medium transition-colors',
                  isActive ? 'bg-gold-50 text-gold-deep' : 'text-ink hover:bg-sand-light',
                )
              }
            >
              {item.label}
            </NavLink>
          ))}
          <div className="mt-2">
            <LanguageSwitcher variant="panel" />
          </div>
          <a href={`tel:${site.phoneRaw}`} className="btn btn-md btn-primary mt-2 w-full">
            <IconPhoneRing className="h-4 w-4" />
            {t.common.callPrefix} {site.phone}
          </a>
        </nav>
      </div>
    </header>
  )
}
