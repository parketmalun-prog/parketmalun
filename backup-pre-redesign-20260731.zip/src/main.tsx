import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { LazyMotion, domAnimation, MotionConfig } from 'framer-motion'
import App from './App'
// Self-hosted fonts — latin + latin-ext subsets ONLY (the site is Icelandic /
// English / Polish, so cyrillic, greek and vietnamese subsets are dead weight).
// Importing per-subset keeps ~30 unused @font-face blocks out of the CSS.
import '@fontsource/inter/latin-400.css'
import '@fontsource/inter/latin-500.css'
import '@fontsource/inter/latin-600.css'
import '@fontsource/inter/latin-700.css'
import '@fontsource/inter/latin-ext-400.css'
import '@fontsource/inter/latin-ext-500.css'
import '@fontsource/inter/latin-ext-600.css'
import '@fontsource/inter/latin-ext-700.css'
import '@fontsource/fraunces/latin-400.css'
import '@fontsource/fraunces/latin-500.css'
import '@fontsource/fraunces/latin-600.css'
import '@fontsource/fraunces/latin-700.css'
import '@fontsource/fraunces/latin-600-italic.css'
import '@fontsource/fraunces/latin-ext-400.css'
import '@fontsource/fraunces/latin-ext-500.css'
import '@fontsource/fraunces/latin-ext-600.css'
import '@fontsource/fraunces/latin-ext-700.css'
import '@fontsource/fraunces/latin-ext-600-italic.css'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {/* domAnimation = the smaller framer-motion feature set (no drag/layout);
        reducedMotion="user" makes every animation honour the OS setting. */}
    <LazyMotion features={domAnimation}>
      <MotionConfig reducedMotion="user">
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </MotionConfig>
    </LazyMotion>
  </React.StrictMode>,
)
