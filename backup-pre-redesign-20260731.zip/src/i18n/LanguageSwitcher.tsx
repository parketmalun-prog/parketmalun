import { useEffect, useRef, useState } from 'react'
import { Globe, Check, ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'
import { LANGS, LANG_LABEL, LANG_NAME } from './config'
import { useLang, useUi } from './context'

type Props = {
  /** 'bar' = compact dropdown for the desktop navbar; 'panel' = inline buttons for the mobile menu. */
  variant?: 'bar' | 'panel'
  className?: string
}

export function LanguageSwitcher({ variant = 'bar', className }: Props) {
  const { lang, setLang } = useLang()
  const t = useUi()
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  // Mobile menu: all three languages inline as a segmented control — no popup,
  // so nothing can be clipped by the menu's overflow-hidden animation container.
  if (variant === 'panel') {
    return (
      <div role="group" aria-label={t.a11y.switcher} className={cn('grid grid-cols-3 gap-2', className)}>
        {LANGS.map((l) => {
          const active = l === lang
          return (
            <button
              key={l}
              type="button"
              aria-pressed={active}
              onClick={() => {
                if (!active) setLang(l)
              }}
              className={cn(
                'flex flex-col items-center rounded-xl border px-2 py-2.5 transition-colors',
                active ? 'border-gold bg-gold-50 text-gold-deep' : 'border-line bg-white text-ink hover:border-gold/50',
              )}
            >
              <span className={cn('text-[11px] font-semibold uppercase tracking-[0.14em]', active ? 'text-gold-deep' : 'text-taupe')}>
                {LANG_LABEL[l]}
              </span>
              <span className="mt-0.5 text-sm font-medium">{LANG_NAME[l]}</span>
            </button>
          )
        })}
      </div>
    )
  }

  return (
    <div ref={ref} className={cn('relative', className)}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={t.a11y.switcher}
        className="inline-flex h-11 items-center gap-1.5 rounded-full border border-espresso/15 px-3 text-sm font-medium text-espresso transition-colors hover:border-gold hover:text-gold-deep"
      >
        <Globe className="h-4 w-4 text-gold-deep" />
        <span>{LANG_LABEL[lang]}</span>
        <ChevronDown className={cn('h-3.5 w-3.5 transition-transform', open && 'rotate-180')} aria-hidden />
      </button>

      {open && (
        <ul
          role="listbox"
          aria-label={t.a11y.switcher}
          className="absolute right-0 top-[calc(100%+8px)] z-50 min-w-[10rem] overflow-hidden rounded-2xl border border-line bg-white p-1.5 shadow-card"
        >
          {LANGS.map((l) => {
            const active = l === lang
            return (
              <li key={l}>
                <button
                  type="button"
                  role="option"
                  aria-selected={active}
                  onClick={() => {
                    setOpen(false)
                    if (!active) setLang(l)
                  }}
                  className={cn(
                    'flex w-full items-center justify-between gap-3 rounded-xl px-3.5 py-2.5 text-left text-sm transition-colors',
                    active ? 'bg-gold-50 text-gold-deep' : 'text-ink hover:bg-sand-light',
                  )}
                >
                  <span className="flex items-center gap-2.5">
                    <span className="w-6 text-xs font-semibold uppercase tracking-wide text-taupe">{LANG_LABEL[l]}</span>
                    {LANG_NAME[l]}
                  </span>
                  {active && <Check className="h-4 w-4" />}
                </button>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
