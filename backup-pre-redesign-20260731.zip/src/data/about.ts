import type { Lang } from '@/i18n/config'

type SeoText = { title: string; description: string }
type TitleText = { title: string; text: string }
type About = {
  eyebrow: string
  title: string
  lead: string
  paragraphs: string[]
  aboutImageId: string
  values: TitleText[]
  whyChoose: TitleText[]
  serviceArea: { title: string; text: string; areas: string[] }
  faq: { q: string; a: string }[]
}

export const aboutSeo: Record<Lang, SeoText> = {
  is: {
    title: 'Um okkur | Expert Parket og Mál — 25+ ára reynsla',
    description:
      'Fjölskyldurekið fagfyrirtæki með yfir 25 ára reynslu í parketlögn, slípun og málun á höfuðborgarsvæðinu. Gæði, reynsla, áreiðanleiki og fagmennska.',
  },
  en: {
    title: 'About us | Expert Parket og Mál — 25+ years of experience',
    description:
      'A family-run professional company with over 25 years of experience in parquet laying, sanding and painting in the capital region. Quality, experience, reliability and professionalism.',
  },
  pl: {
    title: 'O nas | Expert Parket og Mál — ponad 25 lat doświadczenia',
    description:
      'Rodzinna firma z ponad 25-letnim doświadczeniem w układaniu parkietu, cyklinowaniu i malowaniu w regionie stołecznym. Jakość, doświadczenie, rzetelność i profesjonalizm.',
  },
}

export const about: Record<Lang, About> = {
  is: {
    eyebrow: 'Um okkur',
    title: 'Handverk sem endist í meira en 25 ár',
    lead: 'Expert Parket og Mál ehf. er fjölskyldurekið fagfyrirtæki á höfuðborgarsvæðinu sem sérhæfir sig í parketlögn, parketslípun og málun — með gæði og fagmennsku að leiðarljósi.',
    paragraphs: [
      'Í meira en 25 ár höfum við lagt, slípað og lakkað gólf á heimilum og fyrirtækjum um allt höfuðborgarsvæðið. Á þeim tíma höfum við lært að gott gólf snýst ekki bara um efnið sjálft, heldur um vandaðan undirbúning, réttu handtökin og natni í hverju smáatriði. Það er einmitt þessi reynsla sem skilar sér í niðurstöðu sem stenst tímans tönn.',
      'Við nálgumst hvert verk af sömu alúð, hvort sem um ræðir eina íbúð, heilt einbýlishús eða atvinnuhúsnæði. Þú talar beint við fagmanninn sem vinnur verkið, færð heiðarlega ráðgjöf frá upphafi og skýrt tilboð án falinna kostnaðarliða. Við mætum á réttum tíma, göngum vel um heimilið þitt og skilum því hreinu og tilbúnu.',
      'Slagorð okkar — „Við sköpum falleg gólf“ — er ekki innantómt loforð heldur það sem við stöndum og föllum með. Markmið okkar er einfalt: að þú sért fullkomlega ánægð eða ánægður með útkomuna og mælir með okkur við aðra.',
    ],
    aboutImageId: '1600210492486-724fe5c67fb0',
    values: [
      { title: 'Gæði', text: 'Við notum vönduð efni og viðurkenndar aðferðir í hverju verki. Gólf sem við leggjum eða slípum eiga að líta vel út — og halda sér fallegum árum saman.' },
      { title: 'Reynsla', text: 'Meira en 25 ára reynsla af parketi og málun þýðir að við þekkjum réttu lausnina fyrir hverjar aðstæður, hvort sem gólfið er gamalt eða nýtt, viður eða harðparket.' },
      { title: 'Áreiðanleiki', text: 'Við mætum á umsömdum tíma, höldum okkur við tímaáætlun og stöndum við tilboðið sem við gerum. Þú veist alltaf hvað þú ert að fá og hvenær.' },
      { title: 'Fagmennska', text: 'Fagleg vinnubrögð frá fyrstu skoðun til frágangs. Við göngum vel um heimilið, þrífum eftir okkur og skilum verki sem við erum stolt af.' },
    ],
    whyChoose: [
      { title: 'Allt á einum stað', text: 'Parketlögn, parketslípun og málun undir sama þaki. Þú þarft ekki að samræma marga iðnaðarmenn — við sjáum um heildarútlit rýmisins.' },
      { title: 'Frí skoðun og skýrt tilboð', text: 'Við komum á staðinn, metum verkið og gerum þér skriflegt tilboð án skuldbindingar. Verðið er gagnsætt og engir faldir kostnaðarliðir bætast við.' },
      { title: 'Vönduð efni og fínn frágangur', text: 'Við veljum lökk, málningu og parket sem henta notkun og umgangi. Kantar, hornlistar og smáatriði fá sömu athygli og stóru fletirnir.' },
      { title: 'Ánægðir viðskiptavinir til margra ára', text: 'Stór hluti verkefna okkar kemur frá meðmælum og endurteknum viðskiptum. Traust sem byggist upp á aldarfjórðungi verður ekki keypt — það er áunnið.' },
    ],
    serviceArea: {
      title: 'Þjónustusvæði',
      text: 'Við þjónustum allt höfuðborgarsvæðið og nágrenni. Hafðu samband í síma 785 7079 eða á expertparket2024@gmail.com og við komum og skoðum verkið þér að kostnaðarlausu.',
      areas: ['Reykjavík', 'Kópavogur', 'Hafnarfjörður', 'Garðabær', 'Mosfellsbær', 'Seltjarnarnes', 'Álftanes', 'Kjósarhreppur'],
    },
    faq: [
      {
        q: 'Hvað kostar að leggja parket?',
        a: 'Verðið ræðst af fermetrafjölda, gerð parketsins og ástandi undirlagsins. Fyrir venjulega parketlögn er algengt bil um 2.500–4.500 kr. á fermetra, en nákvæmt verð fer eftir aðstæðum. Við komum og gerum þér frítt, skriflegt tilboð áður en verkið hefst.',
      },
      {
        q: 'Er hægt að slípa gamalt parket í stað þess að skipta um það?',
        a: 'Já, í flestum tilfellum. Ef gólfið er úr gegnheilum viði eða þykku spónlögðu parketi má oftast slípa það niður, gera við rispur og lakka upp á nýtt — það lítur út eins og nýtt gólf fyrir mun lægri kostnað en að skipta um. Við metum þykkt og ástand slitlagsins við skoðun og segjum þér hreinskilnislega hvort slípun borgi sig.',
      },
      {
        q: 'Hversu langan tíma tekur að slípa og lakka gólf, og get ég búið heima á meðan?',
        a: 'Fyrir venjulega íbúð tekur slípun og lökkun oftast 2–4 daga, meðal annars vegna þess að lakkið þarf að þorna á milli umferða. Hægt er að búa í húsnæðinu ef vinnusvæðið er afmarkað, en best er að ganga sem minnst á nýlökkuðu gólfin fyrstu dagana á meðan lakkið harðnar að fullu.',
      },
      {
        q: 'Hversu oft þarf að endurslípa parket?',
        a: 'Það fer eftir umgangi og gerð lakks, en gott parket á heimili þarf yfirleitt aðeins að endurslípa á 10–20 ára fresti. Á milli slípana má oft fríska gólfið upp með léttri yfirlökkun (skrúbb og lakk) sem lengir líftímann töluvert án þess að slípa niður í viðinn.',
      },
      {
        q: 'Þarf ég að undirbúa eitthvað fyrir málun, eða sjáið þið um allt?',
        a: 'Við sjáum um allan fagmannlega undirbúninginn: spörtlun, slípun, grunnun, límbandsvinnu og að verja gólf og innréttingar. Það hjálpar ef þú getur fjarlægt lausa muni og myndir af veggjunum, en við göngum frá öllu öðru og skilum rýminu hreinu og tilbúnu.',
      },
      {
        q: 'Hvaða parket hentar best — gegnheilt, spónlagt eða harðparket?',
        a: 'Það fer eftir rýminu og notkun. Gegnheilt og spónlagt viðarparket gefur hlýlegt, náttúrulegt yfirbragð og má slípa upp aftur og aftur. Harðparket (laminat) er hagkvæmara og þolir vel mikinn umgang og raka. Við förum yfir kosti og galla með þér út frá herbergi, umferð og fjárhagsáætlun áður en þú velur.',
      },
      {
        q: 'Bjóðið þið ábyrgð á vinnunni og fæ ég frítt tilboð?',
        a: 'Já. Öll skoðun og tilboðsgerð er þér að kostnaðarlausu og án skuldbindingar. Við stöndum að baki handverkinu okkar og ábyrgjumst faglega framkvæmd — komi eitthvað upp á sem rekja má til vinnu okkar leysum við úr því. Hringdu í 785 7079 eða sendu okkur línu á expertparket2024@gmail.com.',
      },
    ],
  },
  en: {
    eyebrow: 'About us',
    title: 'Craftsmanship that has lasted more than 25 years',
    lead: 'Expert Parket og Mál ehf. is a family-run professional company in the capital region specialising in parquet laying, floor sanding and painting — guided by quality and professionalism.',
    paragraphs: [
      'For more than 25 years we have laid, sanded and lacquered floors in homes and businesses across the capital region. In that time we have learned that a good floor is not just about the material itself, but about thorough preparation, the right technique and care in every detail. It is precisely this experience that delivers a result which stands the test of time.',
      'We approach every job with the same care, whether it is a single apartment, an entire house or commercial premises. You speak directly with the craftsman who does the work, get honest advice from the start and a clear quote with no hidden costs. We arrive on time, treat your home with respect and hand it back clean and ready.',
      'Our motto — “We create beautiful floors” — is not an empty promise but what we live and stand by. Our goal is simple: that you are completely happy with the result and recommend us to others.',
    ],
    aboutImageId: '1600210492486-724fe5c67fb0',
    values: [
      { title: 'Quality', text: 'We use quality materials and proven methods on every job. Floors we lay or sand should look great — and stay beautiful for years.' },
      { title: 'Experience', text: 'More than 25 years with parquet and painting means we know the right solution for any situation, whether the floor is old or new, wood or laminate.' },
      { title: 'Reliability', text: 'We arrive at the agreed time, keep to schedule and stand by the quote we give. You always know what you are getting and when.' },
      { title: 'Professionalism', text: 'Professional work from the first inspection to the finishing touches. We respect your home, clean up after ourselves and deliver work we are proud of.' },
    ],
    whyChoose: [
      { title: 'Everything in one place', text: 'Parquet laying, floor sanding and painting under one roof. You do not need to coordinate several tradesmen — we take care of the whole look of the space.' },
      { title: 'Free inspection and a clear quote', text: 'We come to you, assess the job and give you a written quote with no obligation. The price is transparent and no hidden costs are added.' },
      { title: 'Quality materials and a fine finish', text: 'We choose lacquers, paints and parquet suited to the use and traffic. Edges, corner trims and details get the same attention as the large surfaces.' },
      { title: 'Satisfied customers over many years', text: 'A large share of our work comes from recommendations and repeat business. Trust built over a quarter of a century cannot be bought — it is earned.' },
    ],
    serviceArea: {
      title: 'Service area',
      text: 'We serve the whole capital region and surroundings. Get in touch on 785 7079 or at expertparket2024@gmail.com and we will come and inspect the job free of charge.',
      areas: ['Reykjavík', 'Kópavogur', 'Hafnarfjörður', 'Garðabær', 'Mosfellsbær', 'Seltjarnarnes', 'Álftanes', 'Kjósarhreppur'],
    },
    faq: [
      {
        q: 'How much does it cost to lay parquet?',
        a: 'The price depends on the number of square metres, the type of parquet and the condition of the subfloor. For standard parquet laying, a common range is about ISK 2,500–4,500 per square metre, but the exact price depends on the circumstances. We come out and give you a free, written quote before the work begins.',
      },
      {
        q: 'Can old parquet be sanded instead of replaced?',
        a: 'Yes, in most cases. If the floor is solid wood or thick engineered parquet, it can usually be sanded down, scratches repaired and re-lacquered — it looks like a new floor for far less than replacing it. We assess the thickness and condition of the wear layer during the inspection and tell you honestly whether sanding is worthwhile.',
      },
      {
        q: 'How long does it take to sand and lacquer a floor, and can I stay at home during the work?',
        a: 'For a typical apartment, sanding and lacquering usually takes 2–4 days, partly because the lacquer needs to dry between coats. You can stay in the property if the work area is sectioned off, but it is best to walk on the freshly lacquered floors as little as possible in the first few days while the lacquer fully hardens.',
      },
      {
        q: 'How often does parquet need to be re-sanded?',
        a: 'It depends on traffic and the type of lacquer, but good parquet in a home usually only needs re-sanding every 10–20 years. Between sandings, the floor can often be freshened up with a light re-coat (scrub and lacquer) that extends its life considerably without sanding down into the wood.',
      },
      {
        q: 'Do I need to prepare anything for painting, or do you handle everything?',
        a: 'We handle all the professional preparation: filling, sanding, priming, masking and protecting floors and fittings. It helps if you can remove loose items and pictures from the walls, but we take care of everything else and hand the space back clean and ready.',
      },
      {
        q: 'Which parquet is best — solid, engineered or laminate?',
        a: 'It depends on the room and its use. Solid and engineered wood parquet gives a warm, natural look and can be sanded again and again. Laminate is more economical and copes well with heavy traffic and moisture. We go over the pros and cons with you based on the room, traffic and budget before you choose.',
      },
      {
        q: 'Do you offer a guarantee on the work and do I get a free quote?',
        a: 'Yes. All inspection and quoting is free of charge and without obligation. We stand behind our craftsmanship and guarantee professional execution — if anything arises that can be traced to our work, we put it right. Call 785 7079 or drop us a line at expertparket2024@gmail.com.',
      },
    ],
  },
  pl: {
    eyebrow: 'O nas',
    title: 'Rzemiosło, które trwa od ponad 25 lat',
    lead: 'Expert Parket og Mál ehf. to rodzinna firma z regionu stołecznego, specjalizująca się w układaniu parkietu, cyklinowaniu i malowaniu — kierująca się jakością i profesjonalizmem.',
    paragraphs: [
      'Od ponad 25 lat układamy, cyklinujemy i lakierujemy podłogi w domach i firmach w całym regionie stołecznym. Przez ten czas nauczyliśmy się, że dobra podłoga to nie tylko sam materiał, ale staranne przygotowanie, właściwa technika i dbałość o każdy szczegół. To właśnie to doświadczenie przekłada się na efekt odporny na próbę czasu.',
      'Do każdego zlecenia podchodzimy z taką samą troską, niezależnie od tego, czy chodzi o jedno mieszkanie, cały dom, czy lokal użytkowy. Rozmawiasz bezpośrednio z fachowcem, który wykonuje pracę, otrzymujesz uczciwe doradztwo od samego początku i jasną wycenę bez ukrytych kosztów. Przychodzimy na czas, dbamy o Twój dom i oddajemy go czysty i gotowy.',
      'Nasze motto — „Tworzymy piękne podłogi” — nie jest pustą obietnicą, lecz tym, na czym opieramy naszą pracę. Nasz cel jest prosty: abyś był w pełni zadowolony z efektu i polecił nas innym.',
    ],
    aboutImageId: '1600210492486-724fe5c67fb0',
    values: [
      { title: 'Jakość', text: 'Na każdym zleceniu używamy dobrych materiałów i sprawdzonych metod. Podłogi, które układamy lub cyklinujemy, mają wyglądać świetnie — i zachować piękno przez lata.' },
      { title: 'Doświadczenie', text: 'Ponad 25 lat pracy z parkietem i malowaniem oznacza, że znamy właściwe rozwiązanie w każdej sytuacji — niezależnie od tego, czy podłoga jest stara czy nowa, drewniana czy laminowana.' },
      { title: 'Rzetelność', text: 'Przychodzimy o umówionej porze, trzymamy się harmonogramu i dotrzymujemy przedstawionej wyceny. Zawsze wiesz, co i kiedy otrzymasz.' },
      { title: 'Profesjonalizm', text: 'Profesjonalna praca od pierwszych oględzin po wykończenie. Szanujemy Twój dom, sprzątamy po sobie i oddajemy pracę, z której jesteśmy dumni.' },
    ],
    whyChoose: [
      { title: 'Wszystko w jednym miejscu', text: 'Układanie parkietu, cyklinowanie i malowanie pod jednym dachem. Nie musisz koordynować wielu fachowców — my zajmujemy się całościowym wyglądem wnętrza.' },
      { title: 'Bezpłatne oględziny i jasna wycena', text: 'Przyjeżdżamy na miejsce, oceniamy zakres prac i przedstawiamy pisemną wycenę bez zobowiązań. Cena jest przejrzysta, bez ukrytych kosztów.' },
      { title: 'Dobre materiały i staranne wykończenie', text: 'Dobieramy lakiery, farby i parkiet dopasowane do użytkowania i natężenia ruchu. Krawędzie, listwy narożne i detale otrzymują taką samą uwagę jak duże powierzchnie.' },
      { title: 'Zadowoleni klienci od wielu lat', text: 'Duża część naszych zleceń pochodzi z polecenia i od stałych klientów. Zaufania budowanego przez ćwierć wieku nie da się kupić — trzeba je zdobyć.' },
    ],
    serviceArea: {
      title: 'Obszar działania',
      text: 'Obsługujemy cały region stołeczny i okolice. Skontaktuj się pod numerem 785 7079 lub na expertparket2024@gmail.com, a przyjedziemy i bezpłatnie obejrzymy zakres prac.',
      areas: ['Reykjavík', 'Kópavogur', 'Hafnarfjörður', 'Garðabær', 'Mosfellsbær', 'Seltjarnarnes', 'Álftanes', 'Kjósarhreppur'],
    },
    faq: [
      {
        q: 'Ile kosztuje ułożenie parkietu?',
        a: 'Cena zależy od liczby metrów kwadratowych, rodzaju parkietu i stanu podłoża. Przy standardowym układaniu parkietu typowy przedział to około 2 500–4 500 ISK za metr kwadratowy, ale dokładna cena zależy od warunków. Przyjeżdżamy i przygotowujemy bezpłatną, pisemną wycenę przed rozpoczęciem prac.',
      },
      {
        q: 'Czy stary parkiet można cyklinować zamiast wymieniać?',
        a: 'Tak, w większości przypadków. Jeśli podłoga jest z litego drewna lub grubego parkietu warstwowego, zwykle można ją wycyklinować, naprawić zarysowania i polakierować na nowo — wygląda jak nowa podłoga przy znacznie niższym koszcie niż wymiana. Podczas oględzin oceniamy grubość i stan warstwy użytkowej i uczciwie mówimy, czy cyklinowanie się opłaca.',
      },
      {
        q: 'Ile czasu zajmuje cyklinowanie i lakierowanie podłogi i czy mogę w tym czasie mieszkać w domu?',
        a: 'W typowym mieszkaniu cyklinowanie i lakierowanie zwykle zajmuje 2–4 dni, między innymi dlatego, że lakier musi wyschnąć między warstwami. Można mieszkać w lokalu, jeśli obszar prac jest wydzielony, ale najlepiej jak najmniej chodzić po świeżo polakierowanych podłogach przez pierwsze dni, gdy lakier w pełni twardnieje.',
      },
      {
        q: 'Jak często trzeba ponownie cyklinować parkiet?',
        a: 'Zależy to od natężenia ruchu i rodzaju lakieru, ale dobry parkiet w domu zwykle wymaga ponownego cyklinowania tylko co 10–20 lat. Między cyklinowaniami podłogę można często odświeżyć lekkim przelakierowaniem (doczyszczenie i lakier), co znacznie wydłuża jej żywotność bez zdzierania drewna.',
      },
      {
        q: 'Czy muszę coś przygotować do malowania, czy zajmujecie się wszystkim?',
        a: 'Zajmujemy się całym profesjonalnym przygotowaniem: szpachlowaniem, szlifowaniem, gruntowaniem, oklejaniem taśmą oraz zabezpieczeniem podłóg i zabudowy. Pomocne jest, jeśli możesz usunąć luźne przedmioty i obrazy ze ścian, ale resztą zajmujemy się my i oddajemy pomieszczenie czyste i gotowe.',
      },
      {
        q: 'Który parkiet jest najlepszy — lity, warstwowy czy panele?',
        a: 'Zależy to od pomieszczenia i sposobu użytkowania. Parkiet lity i warstwowy z drewna daje ciepły, naturalny wygląd i można go cyklinować wielokrotnie. Panele laminowane są bardziej ekonomiczne i dobrze znoszą duży ruch oraz wilgoć. Omawiamy z Tobą wady i zalety w oparciu o pomieszczenie, natężenie ruchu i budżet, zanim dokonasz wyboru.',
      },
      {
        q: 'Czy dajecie gwarancję na pracę i czy otrzymam bezpłatną wycenę?',
        a: 'Tak. Wszystkie oględziny i wyceny są bezpłatne i niezobowiązujące. Stoimy za naszym rzemiosłem i gwarantujemy profesjonalne wykonanie — jeśli pojawi się cokolwiek, co wynika z naszej pracy, naprawimy to. Zadzwoń pod 785 7079 lub napisz do nas na expertparket2024@gmail.com.',
      },
    ],
  },
}
