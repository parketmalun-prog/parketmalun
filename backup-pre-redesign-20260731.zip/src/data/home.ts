import type { Lang } from '@/i18n/config'
import type { ServiceKey } from './site'

const is = {
  seo: {
    title: 'Expert Parket og Mál | Parketlögn, slípun og málun á höfuðborgarsvæðinu',
    description:
      'Fagmenn með yfir 25 ára reynslu í parketlögn, parketslípun og málun á höfuðborgarsvæðinu. Vönduð vinnubrögð og áreiðanleg þjónusta. Fáðu frítt verðtilboð í síma 785 7079.',
  },
  hero: {
    eyebrow: 'Parketlögn · Parketslípun · Málun',
    titlePre: 'Við sköpum',
    titleAccent: 'falleg gólf',
    titlePost: 'sem endast',
    subtitle:
      'Fagmenn með yfir 25 ára reynslu í parketlögn, slípun og málun á höfuðborgarsvæðinu. Vönduð vinnubrögð, hrein verklok og gólf sem þú verður stoltur af.',
    ctaPrimary: 'Fáðu frítt verðtilboð',
    ctaSecondary: 'Hringdu í 785 7079',
  },
  heroImageId: '1618221195710-dd6b41faaea6',
  craftsmanImageId: '1558618666-fcd25c85cd64',
  trustBar: ['25+ ára reynsla', 'Höfuðborgarsvæðið allt', 'Frítt verðtilboð', 'Vönduð verklok'],
  servicesIntro: {
    eyebrow: 'Þjónusta okkar',
    title: 'Allt fyrir gólfin þín á einum stað',
    subtitle:
      'Frá lagningu á nýju parketi til slípunar á gömlu gólfi og fagmannlegrar málningar. Við tökum að okkur verkið frá upphafi til enda.',
  },
  services: [
    {
      key: 'parket' as ServiceKey,
      title: 'Parketlögn',
      short:
        'Fagmannleg lögn á parketi og viðargólfum með nákvæmni í hverju smáatriði. Traustur undirbúningur, réttar aðferðir og fallegt yfirbragð sem endist í áratugi.',
    },
    {
      key: 'slipun' as ServiceKey,
      title: 'Parketslípun',
      short:
        'Við blásum nýju lífi í slitin gólf. Rykbundin slípun, olíuborn eða lökkun og gólfið lítur út eins og nýtt á ný, án óþarfa sóðaskapar á heimilinu.',
    },
    {
      key: 'malun' as ServiceKey,
      title: 'Málun',
      short:
        'Innimálun og öll almenn málningarvinna með fagmannlegum frágangi. Jafnir fletir, hreinar línur og litir sem lyfta rýminu. Við göngum frá öllu að verki loknu.',
    },
  ],
  whyUs: {
    title: 'Af hverju að velja Expert Parket og Mál?',
    subtitle:
      'Við byggjum á reynslu, gæðum og áreiðanleika. Þú færð fagmann sem stendur við orð sín og skilar verki sem stenst tímans tönn.',
    points: [
      {
        title: 'Yfir 25 ára reynsla',
        text: 'Aldarfjórðungur af parketlögn, slípun og málun. Við höfum séð allt og kunnum réttu handtökin við hverjar aðstæður.',
      },
      {
        title: 'Fagmennska í fyrirrúmi',
        text: 'Rétt verkfæri, réttar aðferðir og athygli á smáatriðum. Við gerum hlutina einu sinni og gerum þá rétt.',
      },
      {
        title: 'Áreiðanleiki sem þú treystir',
        text: 'Við mætum á réttum tíma, höldum áætlun og stöndum við það verð sem við gefum. Engar óvæntar uppákomur.',
      },
      {
        title: 'Hrein og snyrtileg verklok',
        text: 'Við göngum frá og skilum rýminu hreinu. Þú sest inn í fallegt gólf, ekki í rykið eftir okkur.',
      },
    ],
  },
  stats: [
    { value: '25+', label: 'ára reynsla' },
    { value: '1000+', label: 'verk unnin' },
    { value: '100%', label: 'vönduð vinnubrögð' },
  ],
  beforeAfter: {
    eyebrow: 'Fyrir og eftir',
    title: 'Slitin gólf verða sem ný',
    subtitle:
      'Sjáðu muninn sem fagmannleg slípun og rétt yfirborðsmeðferð gera. Gömlu gólfin þín geyma oft fallegt við undir yfirborðinu — við drögum það fram.',
    beforeImageId: '1581858726788-75bc0f6a952d',
    afterImageId: '1519710164239-da123dc03ef4',
  },
  process: {
    title: 'Einfalt ferli frá fyrstu snertingu',
    subtitle: 'Við gerum þér auðvelt fyrir. Þú hringir, við mætum og verkið gengur snurðulaust fyrir sig.',
    steps: [
      { title: 'Hafðu samband', text: 'Hringdu eða sendu okkur línu. Við hlustum á hvað þig vantar og bókum skoðun sem hentar þér.' },
      { title: 'Skoðun og tilboð', text: 'Við komum, metum verkið og gefum þér skýrt og heiðarlegt verðtilboð án skuldbindingar.' },
      { title: 'Verkið unnið', text: 'Fagmennirnir okkar mæta á réttum tíma og vinna verkið af nákvæmni og virðingu fyrir heimili þínu.' },
      { title: 'Falleg verklok', text: 'Við göngum frá öllu, hreinsum eftir okkur og skilum þér gólfi eða rými sem þú verður ánægður með.' },
    ],
  },
  testimonials: [
    {
      name: 'Guðrún Halldórsdóttir',
      location: 'Garðabær',
      quote:
        'Þeir lögðu eikarparket í alla hæðina hjá okkur og útkoman er hreint út sagt glæsileg. Vönduð vinnubrögð, stundvísir og gengu vel frá öllu. Ég mæli eindregið með þeim.',
    },
    {
      name: 'Sigurður Þór Jónsson',
      location: 'Reykjavík',
      quote:
        'Gamla stofugólfið var orðið ansi þreytt en eftir slípun og olíuburð lítur það út eins og nýtt. Ótrúlegur munur og nánast ekkert ryk á meðan. Frábær þjónusta.',
    },
    {
      name: 'Anna Kristín Sigurðardóttir',
      location: 'Kópavogur',
      quote:
        'Þeir máluðu alla íbúðina fyrir okkur áður en við fluttum inn. Hreinar línur, jafnir fletir og allt klárt á umsömdum tíma. Fagmenn fram í fingurgóma.',
    },
    {
      name: 'Ólafur Magnússon',
      location: 'Hafnarfjörður',
      quote:
        'Áreiðanlegir menn sem standa við orð sín. Verðið sem þeir gáfu stóðst og verkið var unnið hratt og vel. Maður finnur að þarna er 25 ára reynsla að baki.',
    },
  ],
  ctaBand: {
    title: 'Tilbúin(n) í falleg gólf?',
    subtitle:
      'Fáðu frítt og óskuldbindandi verðtilboð í dag. Við svörum fljótt og finnum lausn sem hentar þér og þínu heimili.',
    ctaPrimary: 'Fáðu frítt verðtilboð',
    ctaSecondary: 'Hringdu í 785 7079',
    imageId: '1600585154340-be6161a56a0c',
  },
}

type HomeContent = typeof is

const en: HomeContent = {
  seo: {
    title: 'Expert Parket og Mál | Parquet laying, sanding and painting in the capital region',
    description:
      'Craftsmen with over 25 years of experience in parquet laying, floor sanding and painting in the capital region. Quality workmanship and reliable service. Get a free quote — call 785 7079.',
  },
  hero: {
    eyebrow: 'Parquet laying · Floor sanding · Painting',
    titlePre: 'We create',
    titleAccent: 'beautiful floors',
    titlePost: 'that last',
    subtitle:
      'Craftsmen with over 25 years of experience in parquet laying, sanding and painting in the capital region. Quality workmanship, a clean finish and floors you will be proud of.',
    ctaPrimary: 'Get a free quote',
    ctaSecondary: 'Call 785 7079',
  },
  heroImageId: '1618221195710-dd6b41faaea6',
  craftsmanImageId: '1558618666-fcd25c85cd64',
  trustBar: ['25+ years of experience', 'The whole capital region', 'Free quote', 'Quality finish'],
  servicesIntro: {
    eyebrow: 'Our services',
    title: 'Everything for your floors in one place',
    subtitle:
      'From laying new parquet to sanding an old floor and professional painting. We take on the whole job from start to finish.',
  },
  services: [
    {
      key: 'parket',
      title: 'Parquet laying',
      short:
        'Professional laying of parquet and wooden floors with precision in every detail. Solid preparation, the right methods and a beautiful finish that lasts for decades.',
    },
    {
      key: 'slipun',
      title: 'Floor sanding',
      short:
        'We breathe new life into worn floors. Dust-free sanding, oiling or lacquering — and the floor looks brand new again, without unnecessary mess in your home.',
    },
    {
      key: 'malun',
      title: 'Painting',
      short:
        'Interior painting and all general painting work with a professional finish. Even surfaces, clean lines and colours that lift the room. We tidy up everything once the job is done.',
    },
  ],
  whyUs: {
    title: 'Why choose Expert Parket og Mál?',
    subtitle:
      'We build on experience, quality and reliability. You get a craftsman who keeps his word and delivers work that stands the test of time.',
    points: [
      {
        title: 'Over 25 years of experience',
        text: 'A quarter of a century of parquet laying, sanding and painting. We have seen it all and know the right approach for any situation.',
      },
      {
        title: 'Professionalism first',
        text: 'The right tools, the right methods and attention to detail. We do things once and do them right.',
      },
      {
        title: 'Reliability you can trust',
        text: 'We show up on time, keep to schedule and stand by the price we quote. No surprises.',
      },
      {
        title: 'A clean, tidy finish',
        text: 'We clear up and leave the space clean. You move onto a beautiful floor, not into our dust.',
      },
    ],
  },
  stats: [
    { value: '25+', label: 'years of experience' },
    { value: '1000+', label: 'projects completed' },
    { value: '100%', label: 'quality workmanship' },
  ],
  beforeAfter: {
    eyebrow: 'Before and after',
    title: 'Worn floors become like new',
    subtitle:
      'See the difference that professional sanding and the right surface treatment make. Your old floors often hold beautiful wood beneath the surface — we bring it out.',
    beforeImageId: '1581858726788-75bc0f6a952d',
    afterImageId: '1519710164239-da123dc03ef4',
  },
  process: {
    title: 'A simple process from first contact',
    subtitle: 'We make it easy for you. You call, we show up and the job runs smoothly.',
    steps: [
      { title: 'Get in touch', text: 'Call or drop us a line. We listen to what you need and book an inspection that suits you.' },
      { title: 'Inspection and quote', text: 'We come out, assess the job and give you a clear, honest quote with no obligation.' },
      { title: 'The work is done', text: 'Our craftsmen arrive on time and carry out the work with precision and respect for your home.' },
      { title: 'A beautiful finish', text: 'We tidy everything up, clean up after ourselves and hand over a floor or space you will be happy with.' },
    ],
  },
  testimonials: [
    {
      name: 'Guðrún Halldórsdóttir',
      location: 'Garðabær',
      quote:
        'They laid oak parquet across our whole floor and the result is simply stunning. Quality workmanship, punctual and they finished everything neatly. I highly recommend them.',
    },
    {
      name: 'Sigurður Þór Jónsson',
      location: 'Reykjavík',
      quote:
        'Our old living-room floor was looking pretty tired, but after sanding and oiling it looks like new. An incredible difference and almost no dust during the work. Excellent service.',
    },
    {
      name: 'Anna Kristín Sigurðardóttir',
      location: 'Kópavogur',
      quote:
        'They painted the whole apartment for us before we moved in. Clean lines, even surfaces and everything ready on the agreed date. Professionals to their fingertips.',
    },
    {
      name: 'Ólafur Magnússon',
      location: 'Hafnarfjörður',
      quote:
        'Reliable people who keep their word. The price they quoted held and the work was done quickly and well. You can tell there are 25 years of experience behind it.',
    },
  ],
  ctaBand: {
    title: 'Ready for beautiful floors?',
    subtitle:
      'Get a free, no-obligation quote today. We reply quickly and find a solution that suits you and your home.',
    ctaPrimary: 'Get a free quote',
    ctaSecondary: 'Call 785 7079',
    imageId: '1600585154340-be6161a56a0c',
  },
}

const pl: HomeContent = {
  seo: {
    title: 'Expert Parket og Mál | Układanie parkietu, cyklinowanie i malowanie w regionie stołecznym',
    description:
      'Fachowcy z ponad 25-letnim doświadczeniem w układaniu parkietu, cyklinowaniu i malowaniu w regionie stołecznym. Solidne wykonanie i niezawodna obsługa. Zamów bezpłatną wycenę — tel. 785 7079.',
  },
  hero: {
    eyebrow: 'Układanie parkietu · Cyklinowanie · Malowanie',
    titlePre: 'Tworzymy',
    titleAccent: 'piękne podłogi',
    titlePost: 'które trwają',
    subtitle:
      'Fachowcy z ponad 25-letnim doświadczeniem w układaniu parkietu, cyklinowaniu i malowaniu w regionie stołecznym. Solidne wykonanie, czyste wykończenie i podłogi, z których będziesz dumny.',
    ctaPrimary: 'Zamów bezpłatną wycenę',
    ctaSecondary: 'Zadzwoń pod 785 7079',
  },
  heroImageId: '1618221195710-dd6b41faaea6',
  craftsmanImageId: '1558618666-fcd25c85cd64',
  trustBar: ['25+ lat doświadczenia', 'Cały region stołeczny', 'Bezpłatna wycena', 'Solidne wykończenie'],
  servicesIntro: {
    eyebrow: 'Nasze usługi',
    title: 'Wszystko dla Twoich podłóg w jednym miejscu',
    subtitle:
      'Od układania nowego parkietu po cyklinowanie starej podłogi i profesjonalne malowanie. Realizujemy całość od początku do końca.',
  },
  services: [
    {
      key: 'parket',
      title: 'Układanie parkietu',
      short:
        'Profesjonalne układanie parkietu i podłóg drewnianych z dbałością o każdy szczegół. Solidne przygotowanie, właściwe metody i piękny efekt, który trwa dziesięciolecia.',
    },
    {
      key: 'slipun',
      title: 'Cyklinowanie parkietu',
      short:
        'Tchniemy nowe życie w zniszczone podłogi. Bezpyłowe cyklinowanie, olejowanie lub lakierowanie — i podłoga znów wygląda jak nowa, bez zbędnego bałaganu w domu.',
    },
    {
      key: 'malun',
      title: 'Malowanie',
      short:
        'Malowanie wnętrz i wszelkie prace malarskie z profesjonalnym wykończeniem. Równe powierzchnie, czyste linie i kolory, które ożywiają wnętrze. Po zakończeniu wszystko po sobie sprzątamy.',
    },
  ],
  whyUs: {
    title: 'Dlaczego warto wybrać Expert Parket og Mál?',
    subtitle:
      'Opieramy się na doświadczeniu, jakości i rzetelności. Otrzymujesz fachowca, który dotrzymuje słowa i wykonuje pracę odporną na próbę czasu.',
    points: [
      {
        title: 'Ponad 25 lat doświadczenia',
        text: 'Ćwierć wieku układania parkietu, cyklinowania i malowania. Widzieliśmy wszystko i znamy właściwe rozwiązanie w każdej sytuacji.',
      },
      {
        title: 'Profesjonalizm przede wszystkim',
        text: 'Właściwe narzędzia, właściwe metody i dbałość o szczegóły. Robimy rzeczy raz, a dobrze.',
      },
      {
        title: 'Rzetelność, której możesz zaufać',
        text: 'Przychodzimy na czas, trzymamy się harmonogramu i dotrzymujemy podanej ceny. Żadnych niespodzianek.',
      },
      {
        title: 'Czyste i schludne wykończenie',
        text: 'Sprzątamy i oddajemy pomieszczenie czyste. Wchodzisz na piękną podłogę, a nie w nasz kurz.',
      },
    ],
  },
  stats: [
    { value: '25+', label: 'lat doświadczenia' },
    { value: '1000+', label: 'zrealizowanych prac' },
    { value: '100%', label: 'solidnego wykonania' },
  ],
  beforeAfter: {
    eyebrow: 'Przed i po',
    title: 'Zniszczone podłogi jak nowe',
    subtitle:
      'Zobacz różnicę, jaką robi profesjonalne cyklinowanie i właściwe wykończenie powierzchni. Twoje stare podłogi często kryją piękne drewno pod powierzchnią — my je wydobywamy.',
    beforeImageId: '1581858726788-75bc0f6a952d',
    afterImageId: '1519710164239-da123dc03ef4',
  },
  process: {
    title: 'Prosty proces od pierwszego kontaktu',
    subtitle: 'Ułatwiamy Ci sprawę. Dzwonisz, przyjeżdżamy, a praca przebiega sprawnie.',
    steps: [
      { title: 'Skontaktuj się', text: 'Zadzwoń lub napisz. Wysłuchamy Twoich potrzeb i umówimy oględziny w dogodnym terminie.' },
      { title: 'Oględziny i wycena', text: 'Przyjeżdżamy, oceniamy zakres prac i przedstawiamy jasną, uczciwą wycenę bez zobowiązań.' },
      { title: 'Realizacja prac', text: 'Nasi fachowcy przyjeżdżają na czas i wykonują pracę precyzyjnie, z szacunkiem dla Twojego domu.' },
      { title: 'Piękne wykończenie', text: 'Wszystko porządkujemy, sprzątamy po sobie i oddajemy podłogę lub wnętrze, z którego będziesz zadowolony.' },
    ],
  },
  testimonials: [
    {
      name: 'Guðrún Halldórsdóttir',
      location: 'Garðabær',
      quote:
        'Ułożyli dębowy parkiet na całym piętrze, a efekt jest po prostu wspaniały. Solidna praca, punktualność i wszystko dopięte na ostatni guzik. Gorąco polecam.',
    },
    {
      name: 'Sigurður Þór Jónsson',
      location: 'Reykjavík',
      quote:
        'Stara podłoga w salonie była mocno zmęczona, ale po cyklinowaniu i olejowaniu wygląda jak nowa. Niesamowita różnica i prawie żadnego kurzu podczas prac. Świetna obsługa.',
    },
    {
      name: 'Anna Kristín Sigurðardóttir',
      location: 'Kópavogur',
      quote:
        'Pomalowali nam całe mieszkanie przed przeprowadzką. Czyste linie, równe powierzchnie i wszystko gotowe w umówionym terminie. Fachowcy w każdym calu.',
    },
    {
      name: 'Ólafur Magnússon',
      location: 'Hafnarfjörður',
      quote:
        'Rzetelni ludzie, którzy dotrzymują słowa. Podana cena się zgadzała, a praca została wykonana szybko i dobrze. Czuć, że stoi za tym 25 lat doświadczenia.',
    },
  ],
  ctaBand: {
    title: 'Gotowi na piękne podłogi?',
    subtitle:
      'Zamów dziś bezpłatną, niezobowiązującą wycenę. Odpowiadamy szybko i znajdziemy rozwiązanie dopasowane do Ciebie i Twojego domu.',
    ctaPrimary: 'Zamów bezpłatną wycenę',
    ctaSecondary: 'Zadzwoń pod 785 7079',
    imageId: '1600585154340-be6161a56a0c',
  },
}

export const home: Record<Lang, HomeContent> = { is, en, pl }
