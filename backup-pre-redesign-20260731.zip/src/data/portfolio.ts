import type { Lang } from '@/i18n/config'
import type { ServiceKey } from './site'

export type Project = {
  title: string
  location: string
  /** Stable service key — display label comes from `ui.serviceNames`. */
  service: ServiceKey
  description: string
  tag: string
  imageId: string
}

type Intro = { eyebrow: string; title: string; subtitle: string }
type SeoText = { title: string; description: string }

export const portfolioSeo: Record<Lang, SeoText> = {
  is: {
    title: 'Verkefni | Parketlögn, slípun og málun — Expert Parket og Mál',
    description:
      'Úrval verkefna í parketlögn, slípun og málun á höfuðborgarsvæðinu. Sjáðu dæmi um gólf sem standast tímans tönn.',
  },
  en: {
    title: 'Projects | Parquet laying, sanding and painting — Expert Parket og Mál',
    description:
      'A selection of parquet laying, sanding and painting projects in the capital region. See examples of floors that stand the test of time.',
  },
  pl: {
    title: 'Realizacje | Układanie parkietu, cyklinowanie i malowanie — Expert Parket og Mál',
    description:
      'Wybór realizacji układania parkietu, cyklinowania i malowania w regionie stołecznym. Zobacz przykłady podłóg odpornych na próbę czasu.',
  },
}

export const portfolioIntro: Record<Lang, Intro> = {
  is: {
    eyebrow: 'Verkefni',
    title: 'Gólf sem standast tímans tönn',
    subtitle:
      'Í yfir 25 ár höfum við lagt, slípað og málað fyrir heimili og fyrirtæki á höfuðborgarsvæðinu. Hér er úrval nýlegra verkefna þar sem gæði, reynsla og fagmennska fara saman.',
  },
  en: {
    eyebrow: 'Projects',
    title: 'Floors that stand the test of time',
    subtitle:
      'For over 25 years we have laid, sanded and painted for homes and businesses in the capital region. Here is a selection of recent projects where quality, experience and professionalism come together.',
  },
  pl: {
    eyebrow: 'Realizacje',
    title: 'Podłogi odporne na próbę czasu',
    subtitle:
      'Od ponad 25 lat układamy, cyklinujemy i malujemy dla domów i firm w regionie stołecznym. Oto wybór najnowszych realizacji, w których jakość, doświadczenie i profesjonalizm idą w parze.',
  },
}

export const projects: Record<Lang, Project[]> = {
  is: [
    {
      title: 'Nýtt eikarparket í einbýli',
      location: 'Garðabær',
      service: 'parket',
      description:
        'Við lögðum gegnheilt eikarparket í stofu og hol á tæplega 90 fermetra svæði. Vandað undirlag, nákvæm lögn og olíuborin áferð sem gefur hlýlegt og endingargott gólf til margra ára.',
      tag: 'Gegnheil eik',
      imageId: '1600210492486-724fe5c67fb0',
    },
    {
      title: 'Upprunalegt stofugólf endurlífgað',
      location: 'Reykjavík, Vesturbær',
      service: 'slipun',
      description:
        'Gamalt gólf í eldra timburhúsi var rykbundið slípað og lakkað upp á nýtt. Djúpar rispur hurfu og upprunalegur litur viðarins kom aftur í ljós, öllum til mikillar ánægju.',
      tag: 'Endurnýjun',
      imageId: '1631679706909-1844bbd07221',
    },
    {
      title: 'Málun á nýbyggðri íbúð',
      location: 'Kópavogur, Kársnes',
      service: 'malun',
      description:
        'Heildarmálun á þriggja herbergja íbúð, veggir og loft. Þéttun, sparsl og tvær yfirferðir gáfu jafna og fallega áferð sem tilbúin var fyrir innflutning á réttum tíma.',
      tag: 'Ný íbúð',
      imageId: '1600494603989-9650cf6ddd3d',
    },
    {
      title: 'Parket á tveimur hæðum',
      location: 'Mosfellsbær',
      service: 'parket',
      description:
        'Við lögðum harðparket í öllum svefnherbergjum og á stigagangi. Samfelld lögn milli hæða og snyrtileg tenging við flísar gefa heildstætt og hljóðlátt gólf fyrir stóra fjölskyldu.',
      tag: 'Öll hæðin',
      imageId: '1600566753086-00f18fb6b3ea',
    },
    {
      title: 'Slípun og olíuburður í raðhúsi',
      location: 'Hafnarfjörður, Setberg',
      service: 'slipun',
      description:
        'Slitið stofuparket var slípað niður í grunn og borið olíu í þrígang. Gólfið fékk matta, náttúrulega áferð sem er auðveld í viðhaldi og þolir daglegt álag heimilis.',
      tag: 'Olíuborið',
      imageId: '1618220179428-22790b461013',
    },
    {
      title: 'Málun á sameign fjölbýlis',
      location: 'Reykjavík, Grafarvogur',
      service: 'malun',
      description:
        'Stigagangur og sameiginleg rými í fjölbýli fengu heildarmálun. Við unnum í samráði við húsfélagið, héldum umgangi opnum og skiluðum snyrtilegu verki með lágmarks raski fyrir íbúa.',
      tag: 'Húsfélag',
      imageId: '1616486338812-3dadae4b4ace',
    },
  ],
  en: [
    {
      title: 'New oak parquet in a detached house',
      location: 'Garðabær',
      service: 'parket',
      description:
        'We laid solid oak parquet in the living room and hall over nearly 90 square metres. A solid subfloor, precise laying and an oiled finish give a warm, durable floor for many years.',
      tag: 'Solid oak',
      imageId: '1600210492486-724fe5c67fb0',
    },
    {
      title: 'Original living-room floor revived',
      location: 'Reykjavík, Vesturbær',
      service: 'slipun',
      description:
        'An old floor in an older timber house was sanded dust-free and re-lacquered. Deep scratches disappeared and the original colour of the wood came back to light, to everyone’s delight.',
      tag: 'Renovation',
      imageId: '1631679706909-1844bbd07221',
    },
    {
      title: 'Painting a newly built apartment',
      location: 'Kópavogur, Kársnes',
      service: 'malun',
      description:
        'A complete repaint of a three-room apartment, walls and ceilings. Sealing, filling and two coats gave an even, beautiful finish that was ready for move-in right on time.',
      tag: 'New apartment',
      imageId: '1600494603989-9650cf6ddd3d',
    },
    {
      title: 'Parquet across two floors',
      location: 'Mosfellsbær',
      service: 'parket',
      description:
        'We laid laminate in all the bedrooms and on the staircase. A continuous lay between floors and a neat transition to the tiles give a cohesive, quiet floor for a large family.',
      tag: 'The whole floor',
      imageId: '1600566753086-00f18fb6b3ea',
    },
    {
      title: 'Sanding and oiling in a terraced house',
      location: 'Hafnarfjörður, Setberg',
      service: 'slipun',
      description:
        'A worn living-room parquet was sanded back to bare wood and oiled three times. The floor got a matt, natural finish that is easy to maintain and withstands the daily wear of a home.',
      tag: 'Oiled',
      imageId: '1618220179428-22790b461013',
    },
    {
      title: 'Painting the common areas of an apartment block',
      location: 'Reykjavík, Grafarvogur',
      service: 'malun',
      description:
        'The stairwell and shared spaces of an apartment block got a full repaint. We worked in consultation with the residents’ association, kept access open and delivered tidy work with minimal disruption for residents.',
      tag: 'Residents’ association',
      imageId: '1616486338812-3dadae4b4ace',
    },
  ],
  pl: [
    {
      title: 'Nowy parkiet dębowy w domu jednorodzinnym',
      location: 'Garðabær',
      service: 'parket',
      description:
        'Ułożyliśmy parkiet z litego dębu w salonie i przedpokoju na prawie 90 metrach kwadratowych. Solidne podłoże, precyzyjne układanie i olejowane wykończenie dają ciepłą, trwałą podłogę na wiele lat.',
      tag: 'Lity dąb',
      imageId: '1600210492486-724fe5c67fb0',
    },
    {
      title: 'Odnowiona oryginalna podłoga w salonie',
      location: 'Reykjavík, Vesturbær',
      service: 'slipun',
      description:
        'Stara podłoga w starszym drewnianym domu została wycyklinowana bezpyłowo i na nowo polakierowana. Głębokie zarysowania zniknęły, a pierwotny kolor drewna znów ujrzał światło dzienne, ku wielkiej radości wszystkich.',
      tag: 'Renowacja',
      imageId: '1631679706909-1844bbd07221',
    },
    {
      title: 'Malowanie nowo wybudowanego mieszkania',
      location: 'Kópavogur, Kársnes',
      service: 'malun',
      description:
        'Kompleksowe malowanie trzypokojowego mieszkania, ściany i sufity. Uszczelnianie, szpachlowanie i dwie warstwy dały równe, piękne wykończenie, gotowe na wprowadzenie w terminie.',
      tag: 'Nowe mieszkanie',
      imageId: '1600494603989-9650cf6ddd3d',
    },
    {
      title: 'Parkiet na dwóch kondygnacjach',
      location: 'Mosfellsbær',
      service: 'parket',
      description:
        'Ułożyliśmy panele laminowane we wszystkich sypialniach i na klatce schodowej. Ciągłe układanie między kondygnacjami i schludne połączenie z płytkami dają spójną, cichą podłogę dla dużej rodziny.',
      tag: 'Całe piętro',
      imageId: '1600566753086-00f18fb6b3ea',
    },
    {
      title: 'Cyklinowanie i olejowanie w szeregowcu',
      location: 'Hafnarfjörður, Setberg',
      service: 'slipun',
      description:
        'Zniszczony parkiet w salonie został wycyklinowany do surowego drewna i trzykrotnie naolejowany. Podłoga zyskała matowe, naturalne wykończenie, łatwe w utrzymaniu i odporne na codzienne obciążenie domu.',
      tag: 'Olejowany',
      imageId: '1618220179428-22790b461013',
    },
    {
      title: 'Malowanie części wspólnych bloku',
      location: 'Reykjavík, Grafarvogur',
      service: 'malun',
      description:
        'Klatka schodowa i pomieszczenia wspólne w bloku zostały w całości pomalowane. Pracowaliśmy w porozumieniu ze wspólnotą mieszkaniową, utrzymaliśmy otwarty dostęp i wykonaliśmy schludną pracę przy minimalnych utrudnieniach dla mieszkańców.',
      tag: 'Wspólnota',
      imageId: '1616486338812-3dadae4b4ace',
    },
  ],
}
