import type { Lang } from '@/i18n/config'
import type { ServiceKey } from './site'

export type Service = {
  key: ServiceKey
  title: string
  tagline: string
  paragraphs: string[]
  includes: string[]
  idealFor: string
  benefits: { title: string; text: string }[]
}

type Intro = { eyebrow: string; title: string; subtitle: string }
type SeoText = { title: string; description: string }

export const servicesIntro: Record<Lang, Intro> = {
  is: {
    eyebrow: 'Þjónusta',
    title: 'Handverk sem endist',
    subtitle:
      'Frá fyrsta fjalarborði að síðasta pensilstroki leggjum við okkur alla fram. Þrjár sérgreinar, ein krafa: gæði sem standast tímans tönn.',
  },
  en: {
    eyebrow: 'Services',
    title: 'Craftsmanship that lasts',
    subtitle:
      'From the first board to the last brushstroke, we give it our all. Three specialities, one standard: quality that stands the test of time.',
  },
  pl: {
    eyebrow: 'Usługi',
    title: 'Rzemiosło, które trwa',
    subtitle:
      'Od pierwszej deski po ostatnie pociągnięcie pędzla dajemy z siebie wszystko. Trzy specjalności, jeden wymóg: jakość odporna na próbę czasu.',
  },
}

export const servicesSeo: Record<Lang, SeoText> = {
  is: {
    title: 'Þjónusta | Parketlögn, parketslípun og málun — Expert Parket og Mál',
    description:
      'Parketlögn, parketslípun og málun af fagmennsku. Traustur undirbúningur, vönduð efni og fínn frágangur um allt höfuðborgarsvæðið.',
  },
  en: {
    title: 'Services | Parquet laying, floor sanding and painting — Expert Parket og Mál',
    description:
      'Professional parquet laying, floor sanding and painting. Solid preparation, quality materials and a fine finish across the whole capital region.',
  },
  pl: {
    title: 'Usługi | Układanie parkietu, cyklinowanie i malowanie — Expert Parket og Mál',
    description:
      'Profesjonalne układanie parkietu, cyklinowanie i malowanie. Solidne przygotowanie, dobre materiały i staranne wykończenie w całym regionie stołecznym.',
  },
}

export const services: Record<Lang, Service[]> = {
  is: [
    {
      key: 'parket',
      title: 'Parketlögn',
      tagline: 'Rétt lögð gólf sem liggja slétt og halda sér árum saman',
      paragraphs: [
        'Parketlögn snýst ekki bara um að leggja fjalir — hún snýst um undirbúning, nákvæmni og skilning á efninu. Við byrjum á að meta undirlagið, mæla rakastig og jafna gólfið þar sem þarf, því fallegt parket sem er lagt á skakkt undirlag endist aldrei. Þegar grunnurinn er réttur leggjum við hvert borð af yfirvegun, með réttum þenslurauf við veggi svo viðurinn geti andað og hreyft sig eftir árstíðum án þess að lyfta sér eða gapa.',
        'Við vinnum með gegnheilt parket, spónlagt parket og harðparket (laminat) — og ráðleggjum þér heiðarlega um hvað hentar rýminu, umferðinni og gólfhitanum þínum. Hvort sem þú vilt klassískt eikarparket, fiskibein (herringbone) eða breið nútímaleg borð, þá leggjum við það þannig að samskeytin falli þétt saman og áferðin verði heil og samfelld yfir allt rýmið.',
        'Að 25+ ára reynslu lokum við alltaf verkinu almennilega: gólflistar, þröskuldar og umgjörð frágengin svo ekkert standi eftir hálfklárað. Þú færð gólf sem er þögult undir fæti, slétt viðkomu og tilbúið til að taka á móti daglegu lífi.',
      ],
      includes: [
        'Mat á undirlagi og rakamæling fyrir lögn',
        'Jöfnun og undirbúningur gólfs (flotun ef þarf)',
        'Lögn á gegnheilu, spónlögðu og harðparketi (laminat)',
        'Fiskibein, breið borð og klassísk mynstur',
        'Rétt þenslurauf og fagmannlegur frágangur við veggi',
        'Uppsetning gólflista, þröskulda og umgjarðar',
      ],
      idealFor:
        'Nýbyggingar, endurgerð íbúða og heimili sem vilja skipta út gömlu gólfefni fyrir varanlegt, fallegt parket.',
      benefits: [
        { title: 'Réttur undirbúningur', text: 'Við mælum raka og jöfnum undirlagið áður en fyrsta borðið fer niður — grunnurinn ræður endingunni.' },
        { title: 'Þétt og slétt áferð', text: 'Hvert borð er lagt með nákvæmni svo samskeytin falli saman og gólfið verði samfellt og þögult undir fæti.' },
        { title: 'Rétt efni fyrir rýmið', text: 'Við ráðleggjum heiðarlega um gegnheilt, spónlagt eða harðparket eftir umferð, gólfhita og notkun.' },
        { title: 'Klárað til enda', text: 'Gólflistar, þröskuldar og umgjörð frágengin — verkinu er skilað fullbúnu, ekki hálfnuðu.' },
      ],
    },
    {
      key: 'slipun',
      title: 'Parketslípun',
      tagline: 'Við vekjum gamla gólfið til lífs á ný',
      paragraphs: [
        'Slitið og mattað parket þarf ekki að þýða nýtt gólf. Með réttri slípun náum við að fjarlægja rispur, bletti og gamla lakkið og leiða fram upprunalegan við og lit sem hefur legið falinn í mörg ár. Gólf sem virðist ónýtt getur litið út eins og nýlagt eftir eina almennilega slípun og yfirborðsmeðferð.',
        'Við slípum í nokkrum umferðum með sífellt fínni sandpappír, notum rykbindandi vélar sem halda heimilinu hreinu og komumst með kantslípun alveg upp að veggjum og inn í horn þar sem venjulegar vélar ná ekki. Þegar yfirborðið er orðið silkislétt veljum við saman rétta meðferð — sterkt gólflakk fyrir mikla umferð, náttúrulega viðarolíu fyrir hlýja mjúka áferð, eða hvíttun ef þú vilt ljósari og nútímalegri blæ.',
        'Niðurstaðan er gólf sem er ekki aðeins fallegt heldur varið — olía eða lakk sem ver viðinn gegn sliti, raka og daglegu álagi svo þú njótir þess miklu lengur. Þetta er umhverfisvæn og hagkvæm leið til að endurnýja heimilið án þess að rífa neitt upp.',
      ],
      includes: [
        'Slípun í mörgum umferðum með fínni og fínni pappír',
        'Kantslípun upp að veggjum og inn í horn',
        'Rykbindandi vélar sem halda rykinu í lágmarki',
        'Viðgerð á rispum, blettum og minni skemmdum',
        'Lökkun, olíuburður eða hvíttun eftir óskum',
        'Val um matt, silki- eða gljáandi áferð',
      ],
      idealFor:
        'Eldri gegnheil parketgólf, stigahandrið og gólf sem hafa slitnað, dofnað eða fengið bletti með tímanum.',
      benefits: [
        { title: 'Nýtt gólf án þess að skipta', text: 'Við fjarlægjum rispur og gamalt lakk og leiðum fram upprunalega viðinn — miklu hagkvæmara en ný lögn.' },
        { title: 'Silkislétt yfirborð', text: 'Slípað í mörgum umferðum með sífellt fínni pappír þar til áferðin er fullkomlega jöfn viðkomu.' },
        { title: 'Hreint verk, lítið ryk', text: 'Rykbindandi vélar halda heimilinu hreinu meðan á vinnu stendur og kantslípun nær alveg upp að vegg.' },
        { title: 'Varið til framtíðar', text: 'Lakk, olía eða hvíttun eftir þínum smekk — yfirborð sem stenst umferð, raka og daglegt álag árum saman.' },
      ],
    },
    {
      key: 'malun',
      title: 'Málun',
      tagline: 'Hrein lína, jöfn áferð og litur sem endist',
      paragraphs: [
        'Góð málun byrjar löngu áður en pensillinn snertir vegg. Við kíttum sprungur, spörslum göt og pússum fleti slétta, því fallegur litur á illa undirbúnum vegg dregur aðeins fram gallana. Við breiðum vandlega yfir gólf og húsgögn og límum af skörpum línum svo úrslitin verði hrein og fagmannleg — engir slettur, engar skakkar brúnir.',
        'Við málum innandyra og utan: stofur, svefnherbergi og eldhús, loft og lista, hurðir og karma, og útveggi sem þurfa að standast íslenskt veðurfar. Við notum sterk og endingargóð málningarefni og veljum rétta gerð fyrir hvern flöt — rakaþolna málningu í baðherbergi, þvottheldan flöt í eldhús og gang, og veðurþolna málningu utandyra sem ver húsið gegn vindi og bleytu.',
        'Þegar við göngum frá verkinu er allt hreint eftir okkur — límband tekið af á réttum tíma svo brúnirnar verði skarpar, gólf og húsgögn óskemmd og herbergið tilbúið til notkunar. Litur sem er rétt borinn á endist árum saman, og áferðin verður jöfn hvernig sem birtan fellur á vegginn.',
      ],
      includes: [
        'Undirbúningur flata: kíttun, spörslun og pússning',
        'Yfirbreiðsla á gólf og húsgögn, líming af línum',
        'Málun innandyra: veggir, loft, listar, hurðir og karmar',
        'Útimálun sem stenst íslenskt veðurfar',
        'Rakaþolin og þvottheld málning í bað, eldhús og ganga',
        'Þrif og fágaður frágangur að verki loknu',
      ],
      idealFor:
        'Heimili og fyrirtæki sem vilja fríska upp á rými, mála eftir framkvæmdir eða vernda húsið að utan.',
      benefits: [
        { title: 'Vandaður undirbúningur', text: 'Við kíttum, spörslum og pússum áður en málað er svo áferðin verði jöfn og gallar hverfi.' },
        { title: 'Skarpar, hreinar línur', text: 'Nákvæm líming og rétt tímasett límband skila skörpum brúnum milli lita, lofts og lista.' },
        { title: 'Rétt efni á réttan stað', text: 'Rakaþolin málning í bað, þvotthelt í eldhús og veðurþolið utandyra — hvað flöturinn þarf.' },
        { title: 'Snyrtilegur frágangur', text: 'Allt hreint eftir okkur, gólf og húsgögn óskemmd og rýmið tilbúið til notkunar strax.' },
      ],
    },
  ],
  en: [
    {
      key: 'parket',
      title: 'Parquet laying',
      tagline: 'Properly laid floors that lie flat and keep their look for years',
      paragraphs: [
        'Laying parquet is not just about putting down boards — it is about preparation, precision and understanding the material. We start by assessing the subfloor, measuring the moisture level and levelling the floor where needed, because beautiful parquet laid on an uneven subfloor never lasts. Once the base is right, we lay each board with care, leaving the correct expansion gap at the walls so the wood can breathe and move with the seasons without lifting or gapping.',
        'We work with solid parquet, engineered parquet and laminate — and advise you honestly on what suits your room, its traffic and your underfloor heating. Whether you want classic oak parquet, herringbone or wide modern boards, we lay it so the joints sit tightly together and the surface is whole and seamless across the entire room.',
        'With 25+ years of experience, we always finish the job properly: skirting boards, thresholds and trims completed so nothing is left half-done. You get a floor that is silent underfoot, smooth to the touch and ready to take on everyday life.',
      ],
      includes: [
        'Assessment of the subfloor and moisture measurement before laying',
        'Levelling and preparation of the floor (self-levelling if needed)',
        'Laying solid, engineered and laminate parquet',
        'Herringbone, wide boards and classic patterns',
        'Correct expansion gaps and a professional finish at the walls',
        'Fitting of skirting boards, thresholds and trims',
      ],
      idealFor:
        'New builds, apartment renovations and homes that want to replace old flooring with durable, beautiful parquet.',
      benefits: [
        { title: 'Proper preparation', text: 'We measure moisture and level the subfloor before the first board goes down — the base determines how long it lasts.' },
        { title: 'A tight, smooth surface', text: 'Each board is laid with precision so the joints meet and the floor is seamless and silent underfoot.' },
        { title: 'The right material for the room', text: 'We advise honestly on solid, engineered or laminate parquet based on traffic, underfloor heating and use.' },
        { title: 'Finished to the end', text: 'Skirting boards, thresholds and trims completed — the job is handed over fully finished, not half-done.' },
      ],
    },
    {
      key: 'slipun',
      title: 'Floor sanding',
      tagline: 'We bring your old floor back to life',
      paragraphs: [
        'A worn, dull parquet floor does not have to mean a new one. With the right sanding we remove scratches, stains and old lacquer and bring out the original wood and colour that has been hidden for years. A floor that seems beyond saving can look freshly laid after one proper sanding and surface treatment.',
        'We sand in several passes with progressively finer sandpaper, use dust-collecting machines that keep your home clean, and reach right up to the walls and into the corners with edge sanding where ordinary machines cannot. Once the surface is silky smooth, we choose the right treatment together — a tough floor lacquer for heavy traffic, natural wood oil for a warm, soft feel, or a white finish if you want a lighter, more modern look.',
        'The result is a floor that is not only beautiful but protected — oil or lacquer that shields the wood against wear, moisture and daily use, so you enjoy it for far longer. It is an eco-friendly and cost-effective way to renew your home without tearing anything out.',
      ],
      includes: [
        'Sanding in multiple passes with progressively finer paper',
        'Edge sanding right up to the walls and into corners',
        'Dust-collecting machines that keep dust to a minimum',
        'Repair of scratches, stains and minor damage',
        'Lacquering, oiling or a white finish as you prefer',
        'A choice of matt, satin or gloss finish',
      ],
      idealFor:
        'Older solid parquet floors, wooden staircases and floors that have worn, faded or become stained over time.',
      benefits: [
        { title: 'A new floor without replacing it', text: 'We remove scratches and old lacquer and bring out the original wood — far more economical than laying anew.' },
        { title: 'A silky-smooth surface', text: 'Sanded in several passes with ever finer paper until the surface is perfectly even to the touch.' },
        { title: 'Clean work, little dust', text: 'Dust-collecting machines keep your home clean during the work and edge sanding reaches right up to the wall.' },
        { title: 'Protected for the future', text: 'Lacquer, oil or a white finish to your taste — a surface that withstands traffic, moisture and daily use for years.' },
      ],
    },
    {
      key: 'malun',
      title: 'Painting',
      tagline: 'Clean lines, an even finish and colour that lasts',
      paragraphs: [
        'Good painting starts long before the brush touches the wall. We fill cracks, patch holes and sand surfaces smooth, because a beautiful colour on a poorly prepared wall only highlights the flaws. We cover floors and furniture carefully and mask off sharp lines so the result is clean and professional — no splatter, no crooked edges.',
        'We paint indoors and out: living rooms, bedrooms and kitchens, ceilings and trims, doors and frames, and exterior walls that must withstand the Icelandic climate. We use strong, durable paints and choose the right type for each surface — moisture-resistant paint for bathrooms, a washable finish for kitchens and hallways, and weatherproof paint outdoors that protects the house against wind and wet.',
        'When we finish, everything is clean behind us — the masking tape removed at the right moment so the edges are crisp, floors and furniture undamaged and the room ready to use. Colour that is applied correctly lasts for years, and the finish stays even however the light falls on the wall.',
      ],
      includes: [
        'Surface preparation: filling, patching and sanding',
        'Covering floors and furniture, masking off lines',
        'Interior painting: walls, ceilings, trims, doors and frames',
        'Exterior painting that withstands the Icelandic climate',
        'Moisture-resistant, washable paint for bathrooms, kitchens and hallways',
        'Cleaning and a polished finish once the job is done',
      ],
      idealFor:
        'Homes and businesses that want to freshen up a space, paint after renovations or protect the house from the outside.',
      benefits: [
        { title: 'Thorough preparation', text: 'We fill, patch and sand before painting so the finish is even and flaws disappear.' },
        { title: 'Sharp, clean lines', text: 'Precise masking and correctly timed tape give crisp edges between colours, ceiling and trims.' },
        { title: 'The right paint in the right place', text: 'Moisture-resistant paint for bathrooms, washable for kitchens and weatherproof outdoors — whatever the surface needs.' },
        { title: 'A tidy finish', text: 'Everything clean behind us, floors and furniture undamaged and the space ready to use right away.' },
      ],
    },
  ],
  pl: [
    {
      key: 'parket',
      title: 'Układanie parkietu',
      tagline: 'Prawidłowo ułożone podłogi, które leżą równo i zachowują wygląd przez lata',
      paragraphs: [
        'Układanie parkietu to nie tylko kładzenie desek — to przygotowanie, precyzja i zrozumienie materiału. Zaczynamy od oceny podłoża, pomiaru wilgotności i wypoziomowania podłogi tam, gdzie to konieczne, ponieważ piękny parkiet ułożony na nierównym podłożu nigdy nie przetrwa. Gdy podstawa jest właściwa, układamy każdą deskę starannie, zachowując odpowiednią szczelinę dylatacyjną przy ścianach, aby drewno mogło oddychać i pracować wraz z porami roku, bez unoszenia się i rozstępów.',
        'Pracujemy z parkietem litym, parkietem warstwowym i panelami laminowanymi — i doradzamy uczciwie, co pasuje do Twojego pomieszczenia, natężenia ruchu i ogrzewania podłogowego. Niezależnie od tego, czy chcesz klasyczny parkiet dębowy, jodełkę, czy szerokie nowoczesne deski, układamy je tak, aby złącza ściśle do siebie przylegały, a powierzchnia była jednolita i ciągła w całym pomieszczeniu.',
        'Dzięki ponad 25-letniemu doświadczeniu zawsze kończymy pracę jak należy: listwy przypodłogowe, progi i wykończenia dopięte, tak że nic nie pozostaje niedokończone. Otrzymujesz podłogę cichą pod stopami, gładką w dotyku i gotową na codzienne życie.',
      ],
      includes: [
        'Ocena podłoża i pomiar wilgotności przed układaniem',
        'Wyrównanie i przygotowanie podłogi (wylewka samopoziomująca w razie potrzeby)',
        'Układanie parkietu litego, warstwowego i paneli laminowanych',
        'Jodełka, szerokie deski i klasyczne wzory',
        'Prawidłowe szczeliny dylatacyjne i profesjonalne wykończenie przy ścianach',
        'Montaż listew przypodłogowych, progów i wykończeń',
      ],
      idealFor:
        'Nowe budynki, remonty mieszkań i domy, które chcą wymienić starą podłogę na trwały, piękny parkiet.',
      benefits: [
        { title: 'Właściwe przygotowanie', text: 'Mierzymy wilgotność i wyrównujemy podłoże, zanim położymy pierwszą deskę — to podstawa decyduje o trwałości.' },
        { title: 'Zwarta i gładka powierzchnia', text: 'Każda deska jest układana precyzyjnie, aby złącza do siebie przylegały, a podłoga była jednolita i cicha pod stopami.' },
        { title: 'Właściwy materiał do pomieszczenia', text: 'Doradzamy uczciwie w kwestii parkietu litego, warstwowego lub paneli, w zależności od ruchu, ogrzewania podłogowego i użytkowania.' },
        { title: 'Dokończone do końca', text: 'Listwy przypodłogowe, progi i wykończenia gotowe — praca jest oddawana w pełni ukończona, nie w połowie.' },
      ],
    },
    {
      key: 'slipun',
      title: 'Cyklinowanie parkietu',
      tagline: 'Przywracamy starej podłodze życie',
      paragraphs: [
        'Zniszczony i matowy parkiet nie musi oznaczać nowej podłogi. Dzięki właściwemu cyklinowaniu usuwamy zarysowania, plamy i stary lakier oraz wydobywamy oryginalne drewno i kolor, ukryte przez wiele lat. Podłoga, która wydaje się nie do uratowania, może wyglądać jak świeżo ułożona po jednym porządnym cyklinowaniu i wykończeniu powierzchni.',
        'Cyklinujemy w kilku przejściach coraz drobniejszym papierem ściernym, używamy maszyn z odciągiem pyłu, które utrzymują dom w czystości, i docieramy krawędziami aż do ścian oraz w narożniki, gdzie zwykłe maszyny nie sięgają. Gdy powierzchnia jest jedwabiście gładka, wspólnie dobieramy odpowiednie wykończenie — mocny lakier do dużego ruchu, naturalny olej do drewna dla ciepłego, miękkiego efektu, lub bielenie, jeśli chcesz jaśniejszy, bardziej nowoczesny odcień.',
        'Efektem jest podłoga nie tylko piękna, ale i chroniona — olej lub lakier zabezpiecza drewno przed zużyciem, wilgocią i codziennym obciążeniem, dzięki czemu cieszysz się nią znacznie dłużej. To ekologiczny i ekonomiczny sposób na odnowienie domu bez zrywania czegokolwiek.',
      ],
      includes: [
        'Cyklinowanie w wielu przejściach coraz drobniejszym papierem',
        'Cyklinowanie krawędzi aż do ścian i w narożnikach',
        'Maszyny z odciągiem pyłu ograniczające kurz do minimum',
        'Naprawa zarysowań, plam i drobnych uszkodzeń',
        'Lakierowanie, olejowanie lub bielenie według życzenia',
        'Wybór wykończenia matowego, satynowego lub połyskowego',
      ],
      idealFor:
        'Starsze podłogi z parkietu litego, drewniane schody i podłogi, które z czasem się zużyły, wyblakły lub poplamiły.',
      benefits: [
        { title: 'Nowa podłoga bez wymiany', text: 'Usuwamy zarysowania i stary lakier oraz wydobywamy oryginalne drewno — znacznie taniej niż nowe układanie.' },
        { title: 'Jedwabiście gładka powierzchnia', text: 'Cyklinowana w kilku przejściach coraz drobniejszym papierem, aż powierzchnia jest idealnie równa w dotyku.' },
        { title: 'Czysta praca, mało kurzu', text: 'Maszyny z odciągiem pyłu utrzymują dom w czystości podczas prac, a cyklinowanie krawędzi sięga aż do ściany.' },
        { title: 'Zabezpieczona na przyszłość', text: 'Lakier, olej lub bielenie według Twojego gustu — powierzchnia odporna na ruch, wilgoć i codzienne obciążenie przez lata.' },
      ],
    },
    {
      key: 'malun',
      title: 'Malowanie',
      tagline: 'Czyste linie, równe wykończenie i kolor, który trwa',
      paragraphs: [
        'Dobre malowanie zaczyna się na długo przed tym, zanim pędzel dotknie ściany. Wypełniamy pęknięcia, szpachlujemy dziury i szlifujemy powierzchnie na gładko, ponieważ piękny kolor na źle przygotowanej ścianie tylko uwydatnia niedoskonałości. Starannie zabezpieczamy podłogi i meble oraz oklejamy ostre linie taśmą, aby efekt był czysty i profesjonalny — bez zachlapań, bez krzywych krawędzi.',
        'Malujemy wewnątrz i na zewnątrz: salony, sypialnie i kuchnie, sufity i listwy, drzwi i ościeżnice oraz ściany zewnętrzne, które muszą wytrzymać islandzki klimat. Używamy mocnych, trwałych farb i dobieramy właściwy rodzaj do każdej powierzchni — farbę odporną na wilgoć do łazienek, zmywalne wykończenie do kuchni i korytarzy oraz farbę odporną na warunki atmosferyczne na zewnątrz, która chroni dom przed wiatrem i wilgocią.',
        'Gdy kończymy, wszystko po nas jest czyste — taśma maskująca zdjęta we właściwym momencie, aby krawędzie były ostre, podłogi i meble nienaruszone, a pomieszczenie gotowe do użytku. Kolor nałożony prawidłowo trwa latami, a wykończenie pozostaje równe niezależnie od tego, jak światło pada na ścianę.',
      ],
      includes: [
        'Przygotowanie powierzchni: wypełnianie, szpachlowanie i szlifowanie',
        'Zabezpieczenie podłóg i mebli, oklejanie linii taśmą',
        'Malowanie wnętrz: ściany, sufity, listwy, drzwi i ościeżnice',
        'Malowanie elewacji odporne na islandzki klimat',
        'Farba odporna na wilgoć i zmywalna do łazienek, kuchni i korytarzy',
        'Sprzątanie i staranne wykończenie po zakończeniu prac',
      ],
      idealFor:
        'Domy i firmy, które chcą odświeżyć wnętrze, pomalować po remoncie lub zabezpieczyć dom z zewnątrz.',
      benefits: [
        { title: 'Staranne przygotowanie', text: 'Wypełniamy, szpachlujemy i szlifujemy przed malowaniem, aby wykończenie było równe, a niedoskonałości zniknęły.' },
        { title: 'Ostre, czyste linie', text: 'Precyzyjne oklejanie i taśma zdjęta we właściwym czasie dają ostre krawędzie między kolorami, sufitem i listwami.' },
        { title: 'Właściwa farba we właściwym miejscu', text: 'Farba odporna na wilgoć do łazienek, zmywalna do kuchni i odporna na pogodę na zewnątrz — tego, czego wymaga powierzchnia.' },
        { title: 'Schludne wykończenie', text: 'Wszystko po nas czyste, podłogi i meble nienaruszone, a pomieszczenie od razu gotowe do użytku.' },
      ],
    },
  ],
}
