import type { Lang } from '@/i18n/config'

type SeoText = { title: string; description: string }
type ContactContent = {
  eyebrow: string
  title: string
  subtitle: string
  form: {
    nameLabel: string
    namePlaceholder: string
    phoneLabel: string
    phonePlaceholder: string
    emailLabel: string
    emailPlaceholder: string
    serviceLabel: string
    serviceOptions: string[]
    messageLabel: string
    messagePlaceholder: string
    submitLabel: string
    sendingLabel: string
    successTitle: string
    successText: string
    mailtoTitle: string
    mailtoText: string
    errorText: string
    privacyNote: string
  }
  infoTitle: string
  hoursTitle: string
  hours: string[]
  responseNote: string
}

export const contactSeo: Record<Lang, SeoText> = {
  is: {
    title: 'Hafðu samband | Fáðu frítt tilboð — Expert Parket og Mál',
    description:
      'Fáðu frítt og óskuldbindandi verðtilboð í parketlögn, slípun eða málun. Hringdu í 785 7079 eða sendu fyrirspurn. Við svörum innan 24 klst. á virkum dögum.',
  },
  en: {
    title: 'Contact | Get a free quote — Expert Parket og Mál',
    description:
      'Get a free, no-obligation quote for parquet laying, sanding or painting. Call 785 7079 or send an enquiry. We reply within 24 hours on business days.',
  },
  pl: {
    title: 'Kontakt | Zamów bezpłatną wycenę — Expert Parket og Mál',
    description:
      'Zamów bezpłatną, niezobowiązującą wycenę układania parkietu, cyklinowania lub malowania. Zadzwoń pod 785 7079 lub wyślij zapytanie. Odpowiadamy w ciągu 24 godzin w dni robocze.',
  },
}

export const contact: Record<Lang, ContactContent> = {
  is: {
    eyebrow: 'Hafðu samband',
    title: 'Fáðu tilboð í þitt verk',
    subtitle:
      'Segðu okkur frá verkefninu þínu, hvort sem það snýr að parketlögn, slípun eða málun. Við förum yfir málið með þér, veitum heiðarlega ráðgjöf og gerum þér verðtilboð án skuldbindingar.',
    form: {
      nameLabel: 'Nafn',
      namePlaceholder: 'Fullt nafn þitt',
      phoneLabel: 'Símanúmer',
      phonePlaceholder: 'T.d. 785 7079',
      emailLabel: 'Netfang',
      emailPlaceholder: 'nafn@dæmi.is',
      serviceLabel: 'Þjónusta',
      serviceOptions: ['Parketlögn', 'Parketslípun', 'Málun', 'Annað / veit ekki'],
      messageLabel: 'Skilaboð',
      messagePlaceholder:
        'Lýstu verkinu stuttlega — stærð rýmis, staðsetning og hvenær þú vilt láta vinna verkið.',
      submitLabel: 'Senda fyrirspurn',
      sendingLabel: 'Sendi…',
      successTitle: 'Takk fyrir fyrirspurnina!',
      successText:
        'Við höfum móttekið skilaboðin þín og höfum samband við þig eins fljótt og auðið er.',
      mailtoTitle: 'Pósthólfið þitt ætti að opnast',
      mailtoText:
        'Við höfum útbúið tölvupóst með skilaboðunum þínum — ef pósthólfið opnaðist ekki hjá þér, sendu okkur línu beint á expertparket2024@gmail.com eða hringdu í 785 7079.',
      errorText:
        'Eitthvað fór úrskeiðis við sendingu. Vinsamlegast hringdu í 785 7079 eða reyndu aftur.',
      privacyNote:
        'Upplýsingarnar þínar eru einungis notaðar til að svara fyrirspurninni og eru aldrei afhentar þriðja aðila.',
    },
    infoTitle: 'Samskiptaupplýsingar',
    hoursTitle: 'Opnunartími',
    hours: ['Mánudaga–föstudaga: 08:00–18:00', 'Laugardaga og sunnudaga: lokað'],
    responseNote: 'Við svörum yfirleitt fyrirspurnum innan 24 klukkustunda á virkum dögum.',
  },
  en: {
    eyebrow: 'Contact',
    title: 'Get a quote for your project',
    subtitle:
      'Tell us about your project, whether it involves parquet laying, sanding or painting. We go over it with you, give honest advice and prepare a quote with no obligation.',
    form: {
      nameLabel: 'Name',
      namePlaceholder: 'Your full name',
      phoneLabel: 'Phone number',
      phonePlaceholder: 'e.g. 785 7079',
      emailLabel: 'Email',
      emailPlaceholder: 'name@example.com',
      serviceLabel: 'Service',
      serviceOptions: ['Parquet laying', 'Floor sanding', 'Painting', 'Other / not sure'],
      messageLabel: 'Message',
      messagePlaceholder:
        'Briefly describe the job — size of the space, location and when you would like the work done.',
      submitLabel: 'Send enquiry',
      sendingLabel: 'Sending…',
      successTitle: 'Thank you for your enquiry!',
      successText:
        'We have received your message and will get back to you as soon as possible.',
      mailtoTitle: 'Your email client should open',
      mailtoText:
        'We have prepared an email with your message — if your email client did not open, drop us a line directly at expertparket2024@gmail.com or call 785 7079.',
      errorText:
        'Something went wrong while sending. Please call 785 7079 or try again.',
      privacyNote:
        'Your information is used only to respond to your enquiry and is never shared with third parties.',
    },
    infoTitle: 'Contact details',
    hoursTitle: 'Opening hours',
    hours: ['Monday–Friday: 08:00–18:00', 'Saturday–Sunday: closed'],
    responseNote: 'We usually respond to enquiries within 24 hours on business days.',
  },
  pl: {
    eyebrow: 'Kontakt',
    title: 'Zamów wycenę swojego projektu',
    subtitle:
      'Opowiedz nam o swoim projekcie, niezależnie od tego, czy dotyczy układania parkietu, cyklinowania czy malowania. Omówimy go z Tobą, udzielimy uczciwej porady i przygotujemy niezobowiązującą wycenę.',
    form: {
      nameLabel: 'Imię i nazwisko',
      namePlaceholder: 'Twoje imię i nazwisko',
      phoneLabel: 'Numer telefonu',
      phonePlaceholder: 'np. 785 7079',
      emailLabel: 'E-mail',
      emailPlaceholder: 'imie@przyklad.pl',
      serviceLabel: 'Usługa',
      serviceOptions: ['Układanie parkietu', 'Cyklinowanie parkietu', 'Malowanie', 'Inne / nie wiem'],
      messageLabel: 'Wiadomość',
      messagePlaceholder:
        'Opisz krótko zlecenie — wielkość pomieszczenia, lokalizację i kiedy chciałbyś, aby praca została wykonana.',
      submitLabel: 'Wyślij zapytanie',
      sendingLabel: 'Wysyłanie…',
      successTitle: 'Dziękujemy za zapytanie!',
      successText:
        'Otrzymaliśmy Twoją wiadomość i skontaktujemy się z Tobą najszybciej, jak to możliwe.',
      mailtoTitle: 'Twój program pocztowy powinien się otworzyć',
      mailtoText:
        'Przygotowaliśmy e-mail z Twoją wiadomością — jeśli program pocztowy się nie otworzył, napisz do nas bezpośrednio na expertparket2024@gmail.com lub zadzwoń pod 785 7079.',
      errorText:
        'Coś poszło nie tak podczas wysyłania. Zadzwoń pod 785 7079 lub spróbuj ponownie.',
      privacyNote:
        'Twoje dane są wykorzystywane wyłącznie do odpowiedzi na zapytanie i nigdy nie są przekazywane osobom trzecim.',
    },
    infoTitle: 'Dane kontaktowe',
    hoursTitle: 'Godziny otwarcia',
    hours: ['Poniedziałek–piątek: 08:00–18:00', 'Sobota i niedziela: nieczynne'],
    responseNote: 'Zwykle odpowiadamy na zapytania w ciągu 24 godzin w dni robocze.',
  },
}
